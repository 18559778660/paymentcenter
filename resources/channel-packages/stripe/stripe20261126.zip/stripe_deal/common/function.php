<?php
$t0 = $_SERVER["HTTP_HOST"];
define('HTTP_SERVER', 'http://' . $t0);
define('HTTPS_SERVER', 'https://' . $t0);
define('DIR_FS_CATALOG_PAYMENT', DIR_FS_CATALOG . LOCATION_DIR_FS . '/');
define('DIR_FS_CATALOG_COMMON', DIR_FS_CATALOG_PAYMENT . 'common/');
define('DIR_FS_CATALOG_CACHE', DIR_FS_CATALOG_COMMON . 'cache/');
define('DIR_FS_CATALOG_LOG', DIR_FS_CATALOG_COMMON . 'log/');
require(LOCATION_DIRS_FS . "/config.php");

if (!function_exists('post_json')) {
    function post_json($url, $data = array(), $header = array())
    {
        $header[] = 'Content-Type:application/json';
        $header[] = 'Expect:';
        $header[] = 'Connection: close';
        // 提交数据给支付网关，如有错误会提示返回
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5); //设置链接时间
        curl_setopt($ch, CURLOPT_TIMEOUT, 15); //设置超时时间
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        $response = curl_exec($ch);
        if (curl_errno($ch)) {
            return [];
        }
        curl_close($ch);
        return $response;
    }
}

if (!function_exists('post_urlencoded')) {
    function post_urlencoded($url, $params, $header = [])
    {
        if (!$header) {
            $header[] = 'Content-Type: application/x-www-form-urlencoded';
        }
        $header[] = 'Expect:';
        $header[] = 'Connection: close';
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5); //设置链接时间
        curl_setopt($ch, CURLOPT_TIMEOUT, 15); //设置超时时间
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header); // 设置HTTP头部
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE); // 对认证证书来源的检查
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE); // 从证书中检查SSL加密算法是否存在
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));
        curl_setopt($ch, CURLOPT_URL, $url);
        $response = curl_exec($ch);
        curl_close($ch);
        if ($response === FALSE) {
            return false;
        }
        return $response;
    }
}

// 发送请求至支付系统
if (!function_exists('curl_pay')) {
    function curl_pay($url, $token, $data = [])
    {
        $header = [
            'Content-type: application/x-www-form-urlencoded; charset=utf-8',
            "api-token: {$token}",
            "Expect:",
            "Connection: close"
        ];
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5); //设置链接时间
        curl_setopt($ch, CURLOPT_TIMEOUT, 15); //设置超时时间
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (compatible; MSIE 5.01; Windows NT 5.0)');
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_AUTOREFERER, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        $tmpInfo = curl_exec($ch);
        if (curl_errno($ch)) {
            return curl_error($ch);
        }
        curl_close($ch);
        return $tmpInfo;
    }
}

if (!function_exists('getTimezone')) {
    function getTimezone()
    {
        // 获取服务器的时区偏移量（单位：小时）
        return date('Z') / 3600;
    }
}

if (!function_exists('isMobile')) {
    function isMobile()
    {
        $UserAgent = $_SERVER['HTTP_USER_AGENT'];
        $IsMobile = false;
        if (stristr($UserAgent, 'mobile') && !stristr($UserAgent, 'ipad')) {
            $IsMobile = true;
        }
        return $IsMobile;
    }
}

//客户端设备类型（Windows、Mac、ihpone、Android、Linux等）
if (!function_exists('getClientOsInfo')) {
    function getClientOsInfo()
    {
        $agent = $_SERVER['HTTP_USER_AGENT'];
        $osList = [
            'Windows 11' => '/Windows NT 10.0;.*\) rv:.*\) like Gecko/',
            'Windows 10' => '/Windows NT 10.0/i',
            'Windows 8.1' => '/Windows NT 6.3/i',
            'Windows 8' => '/Windows NT 6.2/i',
            'Windows 7' => '/Windows NT 6.1/i',
            'Windows Vista' => '/Windows NT 6.0/i',
            'Windows XP' => '/Windows NT 5.1|Windows XP/i',
            'Windows 2000' => '/Windows NT 5.0/i',
            'Windows ME' => '/Windows ME|Win 9x 4.90/i',
            'Windows 98' => '/Windows 98|Win98/i',
            'Windows 95' => '/Windows 95|Win95/i',
            'Windows NT 4.0' => '/Windows NT 4.0|WinNT4.0/i',
            'Windows CE' => '/Windows CE/i',
            'Windows 3.11' => '/Win16/i',
            'Android' => '/Android/i',
            'iOS' => '/iPhone|iPad|iPod/i',
            'Mac OS X' => '/Mac OS X/i',
            'Macintosh' => '/Mac_PowerPC|Macintosh/i',
            'Linux' => '/Linux/i',
            'Ubuntu' => '/Ubuntu/i',
            'FreeBSD' => '/FreeBSD/i',
            'OpenBSD' => '/OpenBSD/i',
            'NetBSD' => '/NetBSD/i',
            'SunOS' => '/SunOS/i',
            'OS/2' => '/OS\/2/i',
            'BeOS' => '/BeOS/i',
            'AIX' => '/AIX/i',
            'IRIX' => '/IRIX/i',
            'HP-UX' => '/HP-UX/i',
            'Unknown' => '/.*/'
        ];

        foreach ($osList as $os => $pattern) {
            if (preg_match($pattern, $agent)) {
                return $os;
            }
        }

        return 'Unknown';
    }
}

if (!function_exists('getBrowser')) {
    function getBrowser()
    {
        $agent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';

        if (stripos($agent, 'Edge') !== false || stripos($agent, 'Edg') !== false) {
            return 'Edge';
        }
        if (stripos($agent, 'OPR') !== false || stripos($agent, 'Opera') !== false) {
            return 'Opera';
        }
        if (stripos($agent, 'Chrome') !== false && stripos($agent, 'Edg') === false) {
            return 'Chrome';
        }
        if (stripos($agent, 'Safari') !== false && stripos($agent, 'Chrome') === false) {
            return 'Safari';
        }
        if (stripos($agent, 'Firefox') !== false) {
            return 'Firefox';
        }
        if (stripos($agent, 'MSIE') !== false || stripos($agent, 'Trident') !== false) {
            return 'IE';
        }

        return 'Unknown';
    }
}

// 获取设备语言
if (!function_exists('getBrowserLanguage')) {
    function getBrowserLanguage($length = 5)
    {
        if (isset($_SERVER['HTTP_ACCEPT_LANGUAGE'])) {
            $langs = explode(',', $_SERVER['HTTP_ACCEPT_LANGUAGE']);
            if (!empty($langs)) {
                // 提取主语言代码（去掉分号后面的优先级信息）
                return strtolower(substr($langs[0], 0, $length));
            }
        }
        return 'unknown';
    }
}

if (!function_exists('getIntWords')) {
    function getIntWords($str)
    {
        $arr = explode(' ', $str);
        foreach ($arr as $v) {
// 检查字符串中是否有数字
            if (preg_match('/\d/', $v)) {
                return str_replace(',', '', $v);
            }
        }
        return false;
    }
}
// 获取ip地址
if (!function_exists('get_client_ip')) {
    function get_client_ip()
    {
        // Cloudflare 真实 IP
        if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
            return $_SERVER['HTTP_CF_CONNECTING_IP'];
        }
        // 常见的代理字段
        $keys = [
            'HTTP_X_FORWARDED_FOR',
            'HTTP_CLIENT_IP',
            'HTTP_X_FORWARDED',
            'HTTP_X_CLUSTER_CLIENT_IP',
            'HTTP_FORWARDED_FOR',
            'HTTP_FORWARDED',
            'HTTP_X_REAL_IP'
        ];
        foreach ($keys as $key) {
            if (!empty($_SERVER[$key])) {
                $ipList = explode(',', $_SERVER[$key]);
                return trim($ipList[0]);
            }
        }
        // 最后兜底
        return isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '0.0.0.0';
    }
}

if (!function_exists('get_invoice_id')) {
    function get_invoice_id($total = 18)
    {
        // Create random token
        $string = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        $max = strlen($string) - 1;
        $token = '';
        for ($i = 0; $i < $total; $i++) {
            $token .= $string[mt_rand(0, $max)];
        }
        return md5(uniqid(md5(microtime(true)), true)) . $token;
    }
}

// 获取美国、意大利地区二字码
if (!function_exists('getState')) {
    function getState($key = '')
    {
        if (empty($key)) {
            return $key;
        }
        //各州和一些领土以及特殊行政区
        $us_regions = array(
            "Alabama" => "AL",
            "Alaska" => "AK",
            "Arizona" => "AZ",
            "Arkansas" => "AR",
            "California" => "CA",
            "Colorado" => "CO",
            "Connecticut" => "CT",
            "Delaware" => "DE",
            "Florida" => "FL",
            "Georgia" => "GA",
            "Hawaii" => "HI",
            "Idaho" => "ID",
            "Illinois" => "IL",
            "Indiana" => "IN",
            "Iowa" => "IA",
            "Kansas" => "KS",
            "Kentucky" => "KY",
            "Louisiana" => "LA",
            "Maine" => "ME",
            "Maryland" => "MD",
            "Massachusetts" => "MA",
            "Michigan" => "MI",
            "Minnesota" => "MN",
            "Mississippi" => "MS",
            "Missouri" => "MO",
            "Montana" => "MT",
            "Nebraska" => "NE",
            "Nevada" => "NV",
            "New Hampshire" => "NH",
            "New Jersey" => "NJ",
            "New Mexico" => "NM",
            "New York" => "NY",
            "North Carolina" => "NC",
            "North Dakota" => "ND",
            "Ohio" => "OH",
            "Oklahoma" => "OK",
            "Oregon" => "OR",
            "Pennsylvania" => "PA",
            "Rhode Island" => "RI",
            "South Carolina" => "SC",
            "South Dakota" => "SD",
            "Tennessee" => "TN",
            "Texas" => "TX",
            "Utah" => "UT",
            "Vermont" => "VT",
            "Virginia" => "VA",
            "Washington" => "WA",
            "West Virginia" => "WV",
            "Wisconsin" => "WI",
            "Wyoming" => "WY",
            "District of Columbia" => "DC",
            "American Samoa" => "AS",
            "Guam" => "GU",
            "Northern Mariana Islands" => "MP",
            "Puerto Rico" => "PR",
            "Palau" => "PW",
            "United States Minor Outlying Islands" => "UM",
            "U.S. Virgin Islands" => "VI",
            "Marshall Islands" => "MH",
            "Armed Forces Americas" => "AA",
            "Armed Forces Europe" => "AE",
            "Armed Forces Pacific" => "AP",
            "Federated States of Micronesia" => "FM",
        );

        $us_regions["Armed Forces Africa"] = "AF"; //美国军事组织中的不同区域
        $us_regions["Armed Forces Canada"] = "AC"; //美国军事组织中的不同区域
        $us_regions["Armed Forces Middle East"] = "ME";  //美国军事组织中的不同区域
        $us_regions["District Of Columbia"] = "DC"; //大小写差别
        $us_regions["Federated States Of Micronesia"] = "FM"; //大小写差别
        $us_regions["Virgin Islands"] = "VI"; //少了前缀 U.S.

//    return $us_regions;
        //包含加拿大各领土以及特殊行政区的英语名称及其相应两字母缩写的PHP数组
        $canada_regions = array(
            "Alberta" => "AB",
            "British Columbia" => "BC",
            "Manitoba" => "MB",
            "New Brunswick" => "NB",
            "Newfoundland and Labrador" => "NL",
            "Nova Scotia" => "NS",
            "Ontario" => "ON",
            "Prince Edward Island" => "PE",
            "Quebec" => "QC",
            "Saskatchewan" => "SK",
            "Northwest Territories" => "NT",
            "Nunavut" => "NU",
            "Yukon" => "YT",
            "Armed Forces Canada" => "CA"
        );
        $canada_regions["Yukon Territory"] = "YT"; //多了后缀 Territory
        $array = array_merge($us_regions, $canada_regions);
        return isset($array[$key]) ? $array[$key] : $key;
    }
}

// 获取国家电话区号
if (!function_exists('phoneCountry')) {
    function phoneCountry($country)
    {
        $json = '{"AF":"93","AX":"358","AL":"355","DZ":"213","AS":"1684","AD":"376","AO":"244","AI":"1264","AQ":"672","AG":"1268","AR":"54","AM":"374","AW":"297","AU":"61","AT":"43","AZ":"994","BS":"1242","BH":"973","BD":"880","BB":"1246","BY":"375","BE":"32","BZ":"501","BJ":"229","BM":"1441","BT":"975","BO":"591","BA":"387","BW":"267","BV":"47","BR":"55","IO":"246","BN":"673","BG":"359","BF":"226","BI":"257","KH":"855","CM":"237","CA":"1","CV":"238","KY":"1345","CF":"236","TD":"235","CL":"56","CN":"86","CX":"61","CC":"61","CO":"57","KM":"269","CK":"682","CR":"506","CI":"225","HR":"385","CU":"53","CY":"357","CZ":"420","CD":"243","DK":"45","DJ":"253","DM":"1767","DO":"1809","EC":"593","EG":"20","SV":"503","GQ":"240","ER":"291","EE":"372","ET":"251","FK":"500","FO":"298","FJ":"679","FI":"358","FR":"33","GF":"594","PF":"689","TF":"596","GA":"241","GM":"220","GE":"995","DE":"49","GH":"233","GI":"350","GR":"30","GL":"299","GD":"1473","GP":"590","GU":"1671","GT":"502","GN":"224","GW":"245","GY":"592","HT":"509","HM":"672","VA":"379","HN":"504","HK":"852","HU":"36","IS":"354","IN":"91","ID":"62","IR":"98","IQ":"964","IE":"353","IM":"44","IL":"972","IT":"39","JM":"1876","JP":"81","JO":"962","KZ":"7","KE":"254","KI":"686","KR":"82","KW":"965","KG":"996","LA":"856","LV":"371","LB":"961","LS":"266","LR":"231","LY":"218","LI":"423","LT":"370","LU":"352","MO":"853","MK":"389","MG":"261","MW":"265","MY":"60","MV":"960","ML":"223","MT":"356","MH":"692","MQ":"596","MR":"222","MU":"230","YT":"269","MX":"52","FM":"691","MD":"373","MC":"377","MN":"976","ME":"382","MS":"1664","MA":"212","MZ":"258","MM":"95","NA":"264","NR":"674","NP":"977","NL":"31","AN":"599","NC":"687","NZ":"64","NI":"505","NE":"227","NG":"234","NU":"683","NF":"6723","KP":"850","MP":"1","NO":"47","OM":"968","PK":"92","PW":"680","PS":"970","PA":"507","PG":"63","PY":"595","PE":"51","PH":"63","PN":"64","PL":"48","PT":"351","PR":"1787","QA":"974","CG":"242","RE":"262","RO":"40","RU":"7","RW":"250","KN":"1869","LC":"1758","VC":"1784","PM":"508","WS":"685","SM":"378","ST":"239","SA":"966","SN":"221","RS":"381","SC":"248","SL":"232","SG":"65","SK":"421","SI":"386","SB":"677","SO":"252","ZA":"27","GS":"995","ES":"34","LK":"94","SH":"290","SD":"249","SR":"597","SJ":"47","SZ":"268","SE":"46","CH":"41","SY":"963","TW":"886","TJ":"992","TZ":"255","TH":"66","TL":"670","TG":"228","TK":"690","TO":"676","TT":"1868","TN":"216","TR":"90","TM":"993","TC":"1649","TV":"688","UG":"256","UA":"380","AE":"971","GB":"44","US":"1","UM":"1","UY":"598","UZ":"998","VU":"678","VE":"58","VN":"84","VI":"1340","WF":"681","EH":"210","YE":"967","YU":"338","ZM":"260","ZW":"263","VG":"1284","GG":"44","SS":"211","MF":"1721","JE":"44","SX":"599","CW":"5999","BL":"590","BQ":"599","XK":"381","IC":"3422"}';
        $array = json_decode($json, true);
        return $array[$country] ?: 1;
    }
}

// 获取卡号类型
if (!function_exists('getCardTypeByCardNum')) {
    function getCardTypeByCardNum($cardNumber)
    {
        $cardNumber = preg_replace('/\D/', '', $cardNumber); // 移除非数字字符
        $patterns = [
            'VISA' => '/^4\d{12}(\d{3})?$/',
            'MASTERCARD' => '/^(5[1-5]\d{14}|2[2-7]\d{14})$/',
            'AE' => '/^3[47]\d{13}$/',
            'JCB' => '/^35(2[89]|[3-8]\d)\d{12}$/',
            'DC' => '/^6(011|5\d{2}|4[4-9]\d|22(12[6-9]|1[3-9]|[2-8]\d|9[01]|92[0-5]))\d{12}$/',
            'DINERS' => '/^3(0[0-5]|[68]\d)\d{11}$/',
        ];

        foreach ($patterns as $cardType => $pattern) {
            if (preg_match($pattern, $cardNumber)) {
                return $cardType;
            }
        }
        return 'UNKNOWN';
    }
}

if (!function_exists('removeSpecialChars')) {
    function removeSpecialChars($input)
    {
        return preg_replace('/[^a-zA-Z0-9\s]/', '', $input);
    }
}

if (!function_exists('createXml')) {
    function createXml()
    {
        // 判断是否为WP站
        if (is_dir(DIR_FS_CATALOG . '/wp-includes')) {
            $url = HTTPS_SERVER . '/generate-products-xml.php?token=abc123';
        } else if (is_dir(DIR_FS_CATALOG . '/catalog/model')) {
            $url = HTTPS_SERVER . '/index.php?route=api/goods/generatexml&token=abc123cba&api_token=111';
        } else {
            $url = HTTPS_SERVER . '/index.php?main_page=xml';
        }

        $options = [
            'http' => [
                'method' => "GET",
                'timeout' => 2,
            ],
        ];

        $context = stream_context_create($options);

        $response = @file_get_contents($url, false, $context);

        if ($response !== 'ok') {
            return false;
        } else {
            return true;
        }
    }
}

if (!function_exists('getShellGoods')) {
    function getShellGoods($num)
    {
        if ($num <= 0) {
            return [];
        }

        $file = DIR_FS_CATALOG . 'products_simple.xml';

        // 封装 XML 加载逻辑
        $xml = loadXmlWithFallback($file);
        if (!$xml) {
            return [];
        }

        // 解析商品数据
        $goods = parseProductsFromXml($xml);

        // 随机取指定数量
        return getRandomGoods($goods, $num);
    }
}

/**
 * 加载 XML，失败时尝试重新生成
 */
if (!function_exists('loadXmlWithFallback')) {
    function loadXmlWithFallback($file)
    {
        // 尝试加载现有文件
        $xml = @simplexml_load_file($file);
        if ($xml !== false) {
            return $xml;
        }

        // 加载失败，尝试重新生成
        if (createXml()) {
            $xml = @simplexml_load_file($file);
            if ($xml !== false) {
                return $xml;
            }
        }

        return null;
    }
}
/**
 * 解析 XML 中的商品数据
 */
if (!function_exists('parseProductsFromXml')) {
    function parseProductsFromXml($xml)
    {
        $goods = [];
        foreach ($xml->Product as $product) {
            $goods[] = parseSingleProduct($product);
        }
        return $goods;
    }
}

/**
 * 解析单个商品
 */
if (!function_exists('parseSingleProduct')) {
    function parseSingleProduct($product)
    {
        // 解码基础字段
        $name = removeSpecialChars(base64_decode($product->name));
        $sku = base64_decode($product->sku);
        $price = base64_decode($product->price);
        $image = base64_decode($product->image);
        $url = base64_decode($product->url);

        return [
            'id' => base64_decode($product->product_id),
            'name' => $name,
            'sku' => $sku,
            'price' => $price,
            'attribute' => parseAttributes($product->attribute),
            'image' => formatUrl($image),
            'url' => formatUrl($url),
        ];
    }
}

/**
 * 解析商品属性
 */
if (!function_exists('parseAttributes')) {
    function parseAttributes($attributeData)
    {
        $attributes = json_decode(base64_decode($attributeData), true);
        if (!is_array($attributes)) {
            return [];
        }

        $attr = [];
        foreach ($attributes as $attribute) {
            if (!isset($attribute['option'])) {
                continue;
            }

            $value = '';
            if (isset($attribute['value'])) {
                if (is_array($attribute['value']) && !empty($attribute['value'])) {
                    // 随机选取一个值
                    $value = $attribute['value'][array_rand($attribute['value'])];
                } else {
                    $value = $attribute['value'];
                }
            }

            $attr[] = [
                'option' => $attribute['option'],
                'value' => $value
            ];
        }

        return $attr;
    }
}

/**
 * 格式化 URL（自动补全域名）
 */
if (!function_exists('formatUrl')) {
    function formatUrl($url)
    {
        if (empty($url)) {
            return '';
        }

        if (strpos($url, 'http') === 0) {
            return $url;
        }

        return HTTPS_SERVER . $url;
    }
}

/**
 * 随机获取指定数量的商品
 */
if (!function_exists('getRandomGoods')) {
    function getRandomGoods($goods, $num)
    {
        $goodsCount = count($goods);

        if ($goodsCount < $num || $num <= 0) {
            return [];
        }

        if ($num === 1) {
            return [$goods[array_rand($goods)]];
        }

        // 随机打乱并取前 $num 个
        shuffle($goods);
        return array_slice($goods, 0, $num);
    }
}

// 获取壳站商品数据
if (!function_exists('getOrderGoods')) {
    function getOrderGoods($fileName, $orderInfoGoods, $amount_ex, $order_number)
    {
        // 参数校验
        if (empty($orderInfoGoods)) {
            return [];
        }

        $path = DIR_FS_CATALOG_CACHE . '/orderGoods';
        if (!is_dir($path)) {
            @mkdir($path, 0777, true);
        }

        $cacheFile = $path . '/' . $fileName . '.txt';
        $cachedGoods = [];

        // 读取缓存
        if (file_exists($cacheFile)) {
            $content = @file_get_contents($cacheFile);
            if ($content !== false) {
                $data = @unserialize($content);
                $cachedGoods = !empty($data['goodsInfo']) ? $data['goodsInfo'] : [];
            }
        }

        // 获取新数据
        if (empty($cachedGoods)) {
            $cachedGoods = getShellGoods(count($orderInfoGoods));
            if (!empty($cachedGoods)) {
                @file_put_contents($cacheFile, serialize(['goodsInfo' => $cachedGoods]), LOCK_EX);
            }
        }

        $strProduct = [];
        $can_rand_pro = false;

        // 构建商品列表
        if (!empty($cachedGoods) && count($cachedGoods) >= count($orderInfoGoods)) {
            $can_rand_pro = true;
            foreach ($orderInfoGoods as $index => $product) {
                $randPro = isset($cachedGoods[$index]) ?$cachedGoods[$index]: [];

                // 验证必要字段
                if (empty($randPro['name'])) {
                    $can_rand_pro = false;
                    break;
                }

                $strProduct[] = [
                    'product_id' => isset($randPro['id']) ? $randPro['id'] : '',
                    'url' => !empty($randPro['url']) ? $randPro['url'] : HTTPS_SERVER,
                    'name' => $randPro['name'],
                    'qty' => isset($product['qty']) ? (int)$product['qty'] : 1,
                    'old_price' => number_format(isset($randPro['price']) ? $randPro['price'] : 0, 2, '.', ''),
                    'price' => number_format(isset($product['price']) ? $product['price'] : 0, 2, '.', ''),
                    'image' => isset($randPro['image']) ? $randPro['image'] : '',
                    'attribute' => isset($randPro['attribute']) ? $randPro['attribute'] : ''
                ];
            }
        }

        // 降级处理
        if (!$can_rand_pro) {
            $strProduct = [[
                'product_id' => '',
                'url' => HTTPS_SERVER,
                'name' => $order_number . ' products',
                'qty' => 1,
                'old_price' => number_format($amount_ex, 2, '.', ''),
                'price' => number_format($amount_ex, 2, '.', ''),
                'image' => '',
                'attribute' => ''
            ]];
        }

        return $strProduct;
    }
}

function getBDomainGoods($total)
{
    if ($total <= 0) {
        return [];
    }

    $file = DIR_FS_CATALOG . 'products_simple.xml';

    // 封装 XML 加载逻辑
    $xml = loadXmlWithFallback($file);
    if (!$xml) {
        return [];
    }

    // 解析商品数据
    $goods = parseProductsFromXml($xml);

    return getPriceMatch($goods, $total);
}

function getBDomainOrderGoods($fileName, $amount_ex, $order_number)
{

    $path = DIR_FS_CATALOG_CACHE . '/orderGoods';
    if (!is_dir($path)) {
        @mkdir($path, 0777, true);
    }

    $cacheFile = $path . '/' . $fileName . '.txt';
    $cachedGoods = [];

    // 读取缓存
    if (file_exists($cacheFile)) {
        $content = @file_get_contents($cacheFile);
        if ($content !== false) {
            $data = @unserialize($content);
            $cachedGoods = !empty($data['goodsInfo']) ? $data['goodsInfo'] : [];
        }
    }

    // 获取新数据
    if (empty($cachedGoods)) {
        $product = getBDomainGoods($amount_ex);
        $cachedGoods = isset($product['selected'])?$product['selected']:[] ;
        if (!empty($cachedGoods)) {
            @file_put_contents($cacheFile, serialize(['goodsInfo' => $cachedGoods]), LOCK_EX);
        }
    }
    // 构建商品列表
    if (!empty($cachedGoods)) {
        return $cachedGoods;
    }

    // 降级处理
    return [[
        'id' => '',
        'url' => HTTPS_SERVER,
        'name' => 'All products #'.$order_number,
        'qty' => 1,
        'old_price' => number_format($amount_ex, 2, '.', ''),
        'price' => number_format($amount_ex, 2, '.', ''),
        'image' => '',
        'attribute' => ''
    ]];
}

/**
 * 递归获取商品组合，使总价【尽可能接近】目标值
 * 最多选 5 个商品，无商品时自动加购最便宜商品
 */
function getPriceMatch(array $goods, $targetPrice, array $selected = array(), $depth = 0, $maxDepth = 5)
{
    // 基础防护
    if ($targetPrice <= 0 || empty($goods)) {
        return formatResult($selected, $targetPrice, $depth, 'invalid_params', '参数异常');
    }

    // 最多选 5 个商品
    $selectedCount = count($selected);
    if ($selectedCount >= 5) {
        return formatResult($selected, $targetPrice, $depth, 'success', '已选满 5 个商品');
    }

    // 递归深度限制
    if ($depth > $maxDepth) {
        return formatResult($selected, $targetPrice, $depth, 'max_depth', '已达最大递归深度');
    }

    // 当前已选总价
    $currentTotal = calculateSelectedTotal($selected);
    $diff = abs($currentTotal - $targetPrice);
    $remaining = $targetPrice - $currentTotal;

    // 结束条件
    if (($remaining <= 0 || $diff < 3) && $depth !== 0 ) {
        return formatResult($selected, $targetPrice, $depth, 'success', '已组合到最优价格');
    }

    // 筛选可用商品
    $availableGoods = filterAvailableGoods($goods, $selected, $remaining);

    // ==================== 核心优化：无可用商品时，自动加购最便宜的 ====================
    if (empty($availableGoods)) {
        // 第一次进入：selected 为空、depth=0
        if (empty($selected) && $depth === 0) {
            $cheapest = getCheapestItem($goods);
            $maxQty = max(1, (int)($targetPrice / $cheapest['price']));
            $cheapest['qty'] = $maxQty;
            $cheapest['total'] = $cheapest['price'] * $maxQty;
            $selected = array($cheapest);
            return formatResult($selected, $targetPrice, $depth, 'success', '首次无可用商品，已自动选择最低价商品');
        }
        if (!empty($selected) && $remaining > 0) {
            $selected = addMaxQtyToCheapestItem($selected, $remaining);
        }
        return formatResult($selected, $targetPrice, $depth, 'optimized', '无可用商品，已自动最大化最便宜商品数量');
    }

    // 从最接近的5个价格随机选一个
    $bestItem = findClosestPriceItem($availableGoods, $remaining);

    // 随机数量 1~最大可买
    $maxCanBuy = floor($remaining / $bestItem['price']);
    $useQty = mt_rand(1, $maxCanBuy);

    // 加入已选列表
    $bestItem['qty'] = $useQty;
    $bestItem['total'] = round($useQty * $bestItem['price'], 2);
    $selected[] = $bestItem;

    // 继续递归
    return getPriceMatch($goods, $targetPrice, $selected, $depth + 1, $maxDepth);
}

/**
 * 获取列表中最便宜的商品
 */
function getCheapestItem(array $goods)
{
    $cheapest = $goods[0];
    foreach ($goods as $item) {
        if ($item['price'] < $cheapest['price']) {
            $cheapest = $item;
        }
    }
    return $cheapest;
}

/**
 * 取前5个最接近价格 → 所有商品 → 随机返回1个
 */
function findClosestPriceItem(array $goods, $target)
{
    if (empty($goods)) return array();

    $itemsWithDiff = array();
    foreach ($goods as $item) {
        $item['diff'] = abs($item['price'] - $target);
        $itemsWithDiff[] = $item;
    }

    usort($itemsWithDiff, function ($a, $b) {
        return $a['diff'] - $b['diff'];
    });

    $topPrices = array();
    foreach ($itemsWithDiff as $item) {
        $topPrices[(string)$item['price']] = true;
        if (count($topPrices) >= 5) break;
    }
    $topPrices = array_keys($topPrices);

    $candidates = array();
    foreach ($goods as $item) {
        if (in_array($item['price'], $topPrices)) {
            $candidates[] = $item;
        }
    }

    return $candidates[array_rand($candidates)];
}

// ------------------------------ 新增：自动给最便宜的商品加购 ------------------------------
function addMaxQtyToCheapestItem($selected, $remaining)
{
    $minPrice = PHP_INT_MAX;
    $minIndex = -1;

    // 找到已选中价格最低的商品
    foreach ($selected as $i => $item) {
        if ($item['price'] < $minPrice) {
            $minPrice = $item['price'];
            $minIndex = $i;
        }
    }

    if ($minIndex >= 0 && $minPrice > 0) {
        $addQty = (int)($remaining / $minPrice);
        if ($addQty > 0) {
            $selected[$minIndex]['qty'] += $addQty;
            $selected[$minIndex]['total'] = $selected[$minIndex]['qty'] * $selected[$minIndex]['price'];
        }
    }
    return $selected;
}

// ------------------------------ 工具函数 ------------------------------
function calculateSelectedTotal(array $selected)
{
    return array_sum(array_column($selected, 'total')) ?: 0.0;
}

function filterAvailableGoods(array $goods, array $selected, $remaining)
{
    $usedNames = array_column($selected, 'name');
    return array_values(array_filter($goods, function ($item) use ($usedNames, $remaining) {
        return !in_array($item["name"], $usedNames, true) && $item["price"] > 0 && $item["price"] <= $remaining;
    }));
}

function formatResult(array $selected, $target, $depth, $status, $message)
{
    $total = calculateSelectedTotal($selected);
    $diff = abs($total - $target);
    $diffPercent = $target > 0 ? round(($diff / $target) * 100, 2) : 0;

    return array(
        'selected' => $selected,
        'total' => round($total, 2),
        'target' => $target,
        'diff' => round($diff, 2),
        'diff_percent' => $diffPercent,
        'status' => $status,
        'message' => $message,
        'depth' => $depth
    );
}

// 添加通道日志
if (!function_exists('addChannelLog')) {

    function addChannelLog($log, $dir = 'newpay')
    {
        date_default_timezone_set('Asia/Shanghai');
        $log = mb_convert_encoding($log, 'gbk', mb_detect_encoding($log));
        $path = DIR_FS_CATALOG_LOG . $dir . "/";
        is_dir($path) || @mkdir($path, 0777, true);
        $fp = fopen($path . 'newpay-log-' . date('Y-m-d') . '.txt', 'a');
        flock($fp, LOCK_EX);
        fwrite($fp, '[' . date('Y-m-d H:i:s') . ']' . $log . "\r\n");
        flock($fp, LOCK_UN);
        fclose($fp);
    }
}

if (!function_exists('useGetParameters')) {

    function useGetParameters($url, $plus)
    {
        $parsedUrl = parse_url($url);

        if (isset($parsedUrl['query'])) {
            // URL 带有 GET 参数
            return $url . '&' . $plus;
        } else {
            // URL 没有 GET 参数
            return $url . '?' . $plus;
        }
    }
}

if (!function_exists('yiyangpaySaveDate')) {
    function yiyangpaySaveDate($xeppFileName, $xeppData)
    {

        if (empty($xeppData['yiyang-time'])) {
            $xeppData['yiyang-time'] = date('Y-m-d H:i:s');
        }

        if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $online_ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } elseif (isset($_SERVER['HTTP_CLIENT_IP'])) {
            $online_ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (isset($_SERVER['HTTP_X_REAL_IP'])) {
            $online_ip = $_SERVER['HTTP_X_REAL_IP'];
        } else {
            $online_ip = $_SERVER['REMOTE_ADDR'];
        }

        if (empty($xeppData['yiyang-ip'])) {
            $xeppData['yiyang-ip'] = $online_ip;
        }

        if (empty($xeppData['yiyang-user-agent'])) {
            $xeppData['yiyang-user-agent'] = $_SERVER['HTTP_USER_AGENT'];
        }

        $fp = fopen($xeppFileName, 'w');
        fputs($fp, serialize($xeppData));
        fclose($fp);

        return $xeppData;
    }
}

if (!function_exists('setSuccessTime')) {
    function setSuccessTime($xeppFileName, $xeppData)
    {
        if (!isset($xeppData['clicks'])) {
            $xeppData['clicks'] = 1;
            $fp = fopen($xeppFileName, 'w');
            fputs($fp, serialize($xeppData));
            fclose($fp);
        }
        return true;
    }
}

if (!function_exists('checkUrl')) {
    function checkUrl($xeppData)
    {
        if (isset($xeppData['clicks'])) {
            redirect(HTTPS_SERVER);
            die;
        }

        if (isset($xeppData['success_time']) && $xeppData['success_time'] < time()) {
            redirect(HTTPS_SERVER);
            die;
        }
    }
}

// 判断是否成功
if (!function_exists('checkSuccessTime')) {
    function checkSuccessTime($xeppFileName, $xeppData)
    {
        if (!isset($xeppData['success_time'])) {
            $xeppData['success_time'] = time() + 1200;
            $fp = fopen($xeppFileName, 'w');
            fputs($fp, serialize($xeppData));
            fclose($fp);
        }
        return true;
    }
}

if (!function_exists('checkYiyangIp')) {
// 验证白名单
    function checkYiyangIp($orderInfoDetails, $order_number, $sys_url, $sys_order_id, $xeppData, $payment_code, $ip_whitelist)
    {
        $no_yiyangpay_customer = false;
        $is_yiyangpay_ok = '';
        $note = '';

        try {
            // ip判断
            $online_ip = get_client_ip();
            if ($ip_whitelist) {
                $ip_whitelist = explode(',', $ip_whitelist);
            }
            if (empty($ip_whitelist) || !in_array($online_ip, $ip_whitelist)) {
                // 浏览器判断
                if (!empty($xeppData['yiyang-user-agent'])) {
                    if ($_SERVER['HTTP_USER_AGENT'] != $xeppData['yiyang-user-agent']) {
                        $no_yiyangpay_customer = true;
                    }
                    $note .= "browser: real-{$xeppData['yiyang-user-agent']} now-{$_SERVER['HTTP_USER_AGENT']};
            ";
                    $now_date = date('Y-m-d H:i:s');
                    $note .= "time: real-{$xeppData['yiyang-time']} now-{$now_date};
            ";
                } else {
                    $no_yiyangpay_customer = true;
                }

                // ip 判断
                if ($no_yiyangpay_customer) {

                    if ($online_ip != $orderInfoDetails['client_ip']) {
                        $is_yiyangpay_ok = $online_ip;
                    } else {
                        $is_yiyangpay_ok = 'ok';
                    }

                    if ($is_yiyangpay_ok != 'ok') {
                        $no_yiyangpay_customer = true;
                    } else {
                        $no_yiyangpay_customer = false;
                    }

                    $note .= "ip: real-{$online_ip} now-{$orderInfoDetails['client_ip']};
            ";
                }

                // cookie判断
                if ($no_yiyangpay_customer) {

                    $unique_yiyangpay = md5($sys_order_id);

                    if ($_COOKIE["{$payment_code}-{$order_number}"] != $unique_yiyangpay) {
                        $no_yiyangpay_customer = true;
                    } else {
                        $no_yiyangpay_customer = false;
                    }

                    $note .= "cookie: real-{$_COOKIE["{$payment_code}-{$order_number}"]} now-{$unique_yiyangpay};
            ";

                }


                if ($no_yiyangpay_customer) {
                    $error_sys_url = $sys_url . 'errorOrderUpdate';
                    $error_sys_data = [
                        'sys_order_id' => $sys_order_id,
                        'ip' => $is_yiyangpay_ok,
                        'order_ip' => $orderInfoDetails['client_ip'],
                        'user_agent' => $_SERVER['HTTP_USER_AGENT'],
                        'note' => !empty($note) ? $note : '',
                        'payment_code' => $payment_code,
                        'order_number' => $order_number
                    ];
                    $error_data_json = curl_pay($error_sys_url, $xeppData['access_token'], $error_sys_data);
                    addChannelLog($order_number . ' return $error_data_json:' . $error_data_json, $payment_code);
                }
            }
        } catch (\Exception $e) {
            addChannelLog($order_number . ' checkYiyangIp :' . $e->getMessage(), $payment_code);
        }

        return $no_yiyangpay_customer;
    }
}

// 保存订单缓存
if (!function_exists('saveOrderCache')) {
    function saveOrderCache($htmlFileName, $orderCache)
    {
        $fp = fopen($htmlFileName, 'w');
        fputs($fp, serialize($orderCache));
        fclose($fp);
    }
}

// 读取订单缓存
if (!function_exists('readOrderCache')) {
    function readOrderCache($xeppFileName)
    {
        return unserialize(implode('', file($xeppFileName)));
    }
}

// 锁
if (!function_exists('lockOrderCache')) {
    function lockOrderCache($xeppFileName, $orderCache)
    {
        while (true) {
            // 如果状态不同于空字符串
            if ($orderCache['cache_order_status'] != 0) {
                return true;
            }

            // 如果超过30秒
            if ($orderCache['cache_order_time'] + 30 < time()) {
                return true;
            }

            // 等待5秒
            sleep(5);

            // 重新读取
            $orderCache = readOrderCache($xeppFileName);
        }
    }
}

// 返回页拦截判断
if (!function_exists('pageVerification')) {
    function pageVerification($orderCache, $is_return_check)
    {
        if ($is_return_check != 1) {
            $data['status'] = false;
            return $data;
        }

        $http_user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
        $data = [
            'ip' => get_client_ip(),
            'referer' => isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '',
            'order_ip' => $orderCache['cache_order_ip'],
            'old_browser' => $orderCache['cache_order_user_agent'],
            'browser' => $http_user_agent,
            'status' => 1
        ];

        // 一次有效
        if (!empty($orderCache['cache_order_clicks']) && $orderCache['cache_order_clicks'] > 0) {
            $data['note'] = '多次返回';
            $data['status'] = 2;
            return $data;
        }

        // 30分钟有效
        if (!empty($orderCache['cache_order_time']) && $orderCache['cache_order_time'] < time() - 480) {
            // 一次有效
            if (!empty($orderCache['cache_order_clicks']) && $orderCache['cache_order_clicks'] > 0) {
                $data['note'] = '二次-返回超时:' . (time() - $orderCache['cache_order_time']);
            } else {
                $data['note'] = '返回超时:' . (time() - $orderCache['cache_order_time']);
            }
            return $data;
        }

        // ip判断
        if ($data['order_ip'] == $data['ip']) {
            $data['status'] = 0;
            $data['note'] = 'IP一致';
            return $data;
        }

//        // 浏览器判断
//        if ($orderCache['cache_order_user_agent'] == $data['browser']) {
//            $data['status'] = 0;
//            $data['note'] = '浏览器一致';
//            return $data;
//        }
        $data['note'] = 'IP不一致';
        return $data;
    }
}

if (!function_exists('toUTF_8')) {
    function toUTF_8($encodedString)
    {
        $replace = [

            // 其他常见特殊字符
            '&lt;' => '', '&gt;' => '', '&#039;' => '', '&amp;' => '', '&quot;' => '',
            '&Auml;' => 'A', '&Ouml;' => 'Oe', '&Uuml;' => 'Ue', '&auml;' => 'ae', '&ouml;' => 'oe', '&uuml;' => 'ue',
            'Ĕ' => 'E', 'Ğ' => 'G', 'Ġ' => 'G', 'Ģ' => 'G', 'Ħ' => 'H', 'Ĩ' => 'I', 'Ĭ' => 'I',
            'Ĳ' => 'IJ', 'Ķ' => 'K', 'Ŋ' => 'N', 'Ŏ' => 'O', 'Ũ' => 'U', 'Ŵ' => 'W', 'Ŷ' => 'Y',
            'ĕ' => 'e', 'ƒ' => 'f', 'ğ' => 'g', 'ġ' => 'g', 'ģ' => 'g', 'ħ' => 'h', 'ĩ' => 'i',
            'ĭ' => 'i', 'ĳ' => 'ij', 'ķ' => 'k', 'ĸ' => 'k', 'ŉ' => 'n', 'ŋ' => 'n', 'ŏ' => 'o',
            'ũ' => 'u', 'ŵ' => 'w', 'ŷ' => 'y', 'э' => 'e', 'ь' => '', 'ſ' => 'ss', 'ый' => 'iy',
            'ы' => 'y', 'Ё' => 'YO', 'ъ' => '', 'Ъ' => '', 'Ы' => 'Y', 'Ь' => '', 'Э' => 'E',
            'ё' => 'yo', 'þ' => 'th', 'Þ' => 'Th',

            // 拉丁字母变音符号
            'á' => 'a', 'à' => 'a', 'ä' => 'a', 'â' => 'a', 'ã' => 'a', 'å' => 'a', 'ā' => 'a', 'ą' => 'a', 'ă' => 'a', 'æ' => 'ae',
            'ç' => 'c', 'ć' => 'c', 'č' => 'c', 'ċ' => 'c',
            'ď' => 'd', 'đ' => 'd', 'ð' => 'd',
            'é' => 'e', 'è' => 'e', 'ë' => 'e', 'ê' => 'e', 'ē' => 'e', 'ė' => 'e', 'ę' => 'e', 'ě' => 'e',
            'í' => 'i', 'ì' => 'i', 'ï' => 'i', 'î' => 'i', 'ī' => 'i', 'į' => 'i', 'ı' => 'i',
            'ł' => 'l', 'ĺ' => 'l', 'ľ' => 'l', 'ļ' => 'l', 'ŀ' => 'l',
            'ñ' => 'n', 'ń' => 'n', 'ň' => 'n', 'ņ' => 'n',
            'ó' => 'o', 'ò' => 'o', 'ö' => 'o', 'ô' => 'o', 'õ' => 'o', 'ø' => 'o', 'ō' => 'o', 'ő' => 'o', 'œ' => 'oe',
            'ŕ' => 'r', 'ř' => 'r', 'ŗ' => 'r',
            'ś' => 's', 'š' => 's', 'ş' => 's', 'ș' => 's', 'ß' => 'ss',
            'ť' => 't', 'ţ' => 't', 'ț' => 't', 'ŧ' => 't',
            'ú' => 'u', 'ù' => 'u', 'ü' => 'u', 'û' => 'u', 'ū' => 'u', 'ů' => 'u', 'ű' => 'u', 'ų' => 'u',
            'ý' => 'y', 'ÿ' => 'y',
            'ž' => 'z', 'ź' => 'z', 'ż' => 'z',

            // 拉丁字母大写变音符号
            'Á' => 'A', 'À' => 'A', 'Ä' => 'A', 'Â' => 'A', 'Ã' => 'A', 'Å' => 'A', 'Ā' => 'A', 'Ą' => 'A', 'Ă' => 'A', 'Æ' => 'AE',
            'Ç' => 'C', 'Ć' => 'C', 'Č' => 'C', 'Ċ' => 'C',
            'Ď' => 'D', 'Đ' => 'D', 'Ð' => 'D',
            'É' => 'E', 'È' => 'E', 'Ë' => 'E', 'Ê' => 'E', 'Ē' => 'E', 'Ė' => 'E', 'Ę' => 'E', 'Ě' => 'E',
            'Í' => 'I', 'Ì' => 'I', 'Ï' => 'I', 'Î' => 'I', 'Ī' => 'I', 'Į' => 'I', 'İ' => 'I',
            'Ł' => 'L', 'Ĺ' => 'L', 'Ľ' => 'L', 'Ļ' => 'L', 'Ŀ' => 'L',
            'Ñ' => 'N', 'Ń' => 'N', 'Ň' => 'N', 'Ņ' => 'N',
            'Ó' => 'O', 'Ò' => 'O', 'Ö' => 'O', 'Ô' => 'O', 'Õ' => 'O', 'Ø' => 'O', 'Ō' => 'O', 'Ő' => 'O', 'Œ' => 'OE',
            'Ŕ' => 'R', 'Ř' => 'R', 'Ŗ' => 'R',
            'Ś' => 'S', 'Š' => 'S', 'Ş' => 'S', 'Ș' => 'S', 'ẞ' => 'SS',
            'Ť' => 'T', 'Ţ' => 'T', 'Ț' => 'T', 'Ŧ' => 'T',
            'Ú' => 'U', 'Ù' => 'U', 'Ü' => 'U', 'Û' => 'U', 'Ū' => 'U', 'Ů' => 'U', 'Ű' => 'U', 'Ų' => 'U',
            'Ý' => 'Y', 'Ÿ' => 'Y',
            'Ž' => 'Z', 'Ź' => 'Z', 'Ż' => 'Z',

            // 希腊语大写字母
            'Α' => 'A', 'Β' => 'B', 'Γ' => 'G', 'Δ' => 'D', 'Ε' => 'E', 'Ζ' => 'Z', 'Η' => 'I', 'Θ' => 'Th',
            'Ι' => 'I', 'Κ' => 'K', 'Λ' => 'L', 'Μ' => 'M', 'Ν' => 'N', 'Ξ' => 'X', 'Ο' => 'O', 'Π' => 'P',
            'Ρ' => 'R', 'Σ' => 'S', 'Τ' => 'T', 'Υ' => 'Y', 'Φ' => 'F', 'Χ' => 'Ch', 'Ψ' => 'Ps', 'Ω' => 'O',
            // 希腊语小写字母
            'α' => 'a', 'β' => 'b', 'γ' => 'g', 'δ' => 'd', 'ε' => 'e', 'ζ' => 'z', 'η' => 'i', 'θ' => 'th',
            'ι' => 'i', 'κ' => 'k', 'λ' => 'l', 'μ' => 'm', 'ν' => 'n', 'ξ' => 'x', 'ο' => 'o', 'π' => 'p',
            'ρ' => 'r', 'σ' => 's', 'ς' => 's', 'τ' => 't', 'υ' => 'y', 'φ' => 'f', 'χ' => 'ch', 'ψ' => 'ps', 'ω' => 'o',
            // 希腊语带音调的字母转换
            'Ά' => 'A', 'Έ' => 'E', 'Ή' => 'I', 'Ί' => 'I', 'Ό' => 'O', 'Ύ' => 'Y', 'Ώ' => 'O',
            'ά' => 'a', 'έ' => 'e', 'ή' => 'i', 'ί' => 'i', 'ό' => 'o', 'ύ' => 'y', 'ώ' => 'o',
            'ϊ' => 'i', 'ϋ' => 'y', 'ΐ' => 'i', 'ΰ' => 'y',

            // 世界语
            'ĉ' => 'cx', 'ĝ' => 'gx', 'ĥ' => 'hx', 'ĵ' => 'jx', 'ŝ' => 'sx', 'ŭ' => 'ux',
            'Ĉ' => 'Cx', 'Ĝ' => 'Gx', 'Ĥ' => 'Hx', 'Ĵ' => 'Jx', 'Ŝ' => 'Sx', 'Ŭ' => 'Ux',

            // 希伯来字母
            'א' => 'a', 'ב' => 'b', 'ג' => 'g', 'ד' => 'd', 'ה' => 'h', 'ו' => 'v', 'ז' => 'z',
            'ח' => 'ch', 'ט' => 't', 'י' => 'y', 'כ' => 'k', 'ך' => 'k', 'ל' => 'l', 'מ' => 'm', 'ם' => 'm',
            'נ' => 'n', 'ן' => 'n', 'ס' => 's', 'ע' => 'a', 'פ' => 'p', 'ף' => 'p', 'צ' => 'tz', 'ץ' => 'tz',
            'ק' => 'k', 'ר' => 'r', 'ש' => 'sh', 'ת' => 't',

            // 乌克兰 - 西里尔字母
            'А' => 'A', 'а' => 'a', 'Б' => 'B', 'б' => 'b', 'В' => 'V', 'в' => 'v', 'Г' => 'H', 'г' => 'h',
            'Ґ' => 'G', 'ґ' => 'g', 'Д' => 'D', 'д' => 'd', 'Е' => 'E', 'е' => 'e', 'Є' => 'Ye', 'є' => 'ie',
            'Ж' => 'Zh', 'ж' => 'zh', 'З' => 'Z', 'з' => 'z', 'И' => 'Y', 'и' => 'y', 'І' => 'I', 'і' => 'i',
            'Ї' => 'Yi', 'ї' => 'i', 'Й' => 'Y', 'й' => 'i', 'К' => 'K', 'к' => 'k', 'Л' => 'L', 'л' => 'l',
            'М' => 'M', 'м' => 'm', 'Н' => 'N', 'н' => 'n', 'О' => 'O', 'о' => 'o', 'П' => 'P', 'п' => 'p',
            'Р' => 'R', 'р' => 'r', 'С' => 'S', 'с' => 's', 'Т' => 'T', 'т' => 't', 'У' => 'U', 'у' => 'u',
            'Ф' => 'F', 'ф' => 'f', 'Х' => 'Kh', 'х' => 'kh', 'Ц' => 'Ts', 'ц' => 'ts', 'Ч' => 'Ch', 'ч' => 'ch',
            'Ш' => 'Sh', 'ш' => 'sh', 'Щ' => 'Shch', 'щ' => 'shch', 'Ю' => 'Yu', 'ю' => 'iu', 'Я' => 'Ya', 'я' => 'ia',

        ];
        return str_replace(array_keys($replace), $replace, $encodedString);
    }
}

if (!function_exists('getSign')) {
    function getSign($data, $secret)
    {
        ksort($data);

        $str = '';
        foreach ($data as $k => $val) {
            if ($val) {
                $str .= $k . '=' . $val . '&';
            }
        }
        $stringB = rtrim($str, '&');

        return md5($stringB . "&key=" . $secret);
    }
}

// 更新系统支付状态
if (!function_exists('updateOrderStatus')) {
    function updateOrderStatus($param, $file_type = 'jump', $notify_type = true)
    {
        // $status '0：未付，1：成功，2：失败，3：取消，4：退款，5：部分退款，6：支付中
        // 通知系统
        $notify_order = [
            'status' => $param['status'],
            'pay_msg' => $param['comment'],
            'pay_amount' => $param['pay_amount'],
            'pay_currency' => $param['pay_currency'],
            'show_amount' => $param['show_amount'],
            'show_usd_amount' => $param['show_usd_amount'],
            'sys_order_id' => $param['sys_order_id'],
            'order_number' => $param['order_number'],
            'invoiceNumber' => $param['invoice_number'],
            'transaction_number' => $param['transaction_number'],
            'note' => isset($param['note']) ? $param['note'] : '',
            'addPayHistory' => [
                'order_id' => $param['sys_order_id'],
                'channel_account_id' => $param['channel_account_id'],
                'channel_id' => $param['channel_id'],
                'domain_id' => $param['b_domain_id'],
                'status' => $param['status'],
                'remark' => isset($param['remark']) ? $param['remark'] : $param['comment'],
                'create_time' => time()
            ],
        ];

        if (!(isset($param['no_jump']) && $param['no_jump'] == 1) && $notify_type) {
            $notify_order['is_asyn'] = 1;
        }
        if (isset($param['fee_money'])){
            $notify_order['fee_money'] = $param['fee_money'];
        }
        if (isset($param['fee_currency_code'])){
            $notify_order['fee_currency_code'] = $param['fee_currency_code'];
        }
        if (isset($param['receivable_currency'])){
            $notify_order['receivable_currency'] = $param['receivable_currency'];
        }
        if (isset($param['receivable_money'])){
            $notify_order['receivable_money'] = $param['receivable_money'];
        }
        if (isset($param['target_currency'])){
            $notify_order['target_currency'] = $param['target_currency'];
        }
        if (isset($param['target_exchange_rate'])){
            $notify_order['target_exchange_rate'] = $param['target_exchange_rate'];
        }

        $notify_data = [
            'order' => @json_encode($notify_order)
        ];
        addChannelLog($param['order_number'] . " {$file_type} sys notify order: " . @json_encode($notify_order), $param['payment_code']);
        $re = curl_pay($param['notify_sys_url'], $param['access_token'], $notify_data);
        addChannelLog($param['order_number'] . " {$file_type} sys notify result: " . $re, $param['payment_code']);
        return json_decode($re, true);
    }
}

// 获取字符串中的数字
if (!function_exists('extractNumbers')) {
    function extractNumbers($string)
    {
        $string = preg_replace('/[^0-9]/', '', $string);
        $string = ltrim($string, '0');
        if (strlen($string) >= 10) {
            return substr($string, 0, 10);
        } else {
            return str_pad($string, 10, "0", STR_PAD_LEFT);
        }
    }
}

if (!function_exists('redirect')) {
    function redirect($url, $httpResponseCode = '')
    {
        while (strstr($url, '&&')) $url = str_replace('&&', '&', $url);
        while (strstr($url, '&amp;&amp;')) $url = str_replace('&amp;&amp;', '&amp;', $url);
        while (strstr($url, '&amp;')) $url = str_replace('&amp;', '&', $url);
        if ($httpResponseCode == '') {
            header('Location: ' . $url);
        } else {
            header('Location: ' . $url, true, (int)$httpResponseCode);
        }
        exit();
    }
}

if (!function_exists('isIPv6')) {
    function isIPv6($ip)
    {
        return filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6) !== false;
    }
}

// ipv6转ipv4
if (!function_exists('ipv6ToIpv4')) {
    function ipv6ToIpv4($ipv6)
    {
        return hexdec(substr($ipv6, 0, 2)) . "." . hexdec(substr($ipv6, 2, 2)) . "." . hexdec(substr($ipv6, 5, 2)) . "." . hexdec(substr($ipv6, 7, 2));
    }
}

if (!function_exists('getBrowserLang')) {
    function getBrowserLang($length = 5)
    {
        if (isset($_SERVER['HTTP_ACCEPT_LANGUAGE'])) {
            $langs = explode(',', $_SERVER['HTTP_ACCEPT_LANGUAGE']);
            if (!empty($langs)) {
                // 提取主语言代码（去掉分号后面的优先级信息）
                return strtolower(substr($langs[0], 0, $length));
            }
        }
        return 'unknown';
    }
}

if (!function_exists('getPhone')) {
    function getPhone($country, $phone)
    {
        if (strpos($phone, '+') !== false) {
            return $phone;
        }
        $json = '{"AF":"+93","AX":"+358","AL":"+355","DZ":"+213","AS":"+1684","AD":"+376","AO":"+244","AI":"+1264","AQ":"+672","AG":"+1268","AR":"+54","AM":"+374","AW":"+297","AU":"+61","AT":"+43","AZ":"+994","BS":"+1242","BH":"+973","BD":"+880","BB":"+1246","BY":"+375","BE":"+32","BZ":"+501","BJ":"+229","BM":"+1441","BT":"+975","BO":"+591","BA":"+387","BW":"+267","BV":"+47","BR":"+55","IO":"+246","BN":"+673","BG":"+359","BF":"+226","BI":"+257","KH":"+855","CM":"+237","CA":"+1","CV":"+238","KY":"+1345","CF":"+236","TD":"+235","CL":"+56","CN":"+86","CX":"+61","CC":"+61","CO":"+57","KM":"+269","CK":"+682","CR":"+506","CI":"+225","HR":"+385","CU":"+53","CY":"+357","CZ":"+420","CD":"+243","DK":"+45","DJ":"+253","DM":"+1767","DO":"+1809","EC":"+593","EG":"+20","SV":"+503","GQ":"+240","ER":"+291","EE":"+372","ET":"+251","FK":"+500","FO":"+298","FJ":"+679","FI":"+358","FR":"+33","GF":"+594","PF":"+689","TF":"+596","GA":"+241","GM":"+220","GE":"+995","DE":"+49","GH":"+233","GI":"+350","GR":"+30","GL":"+299","GD":"+1473","GP":"+590","GU":"+1671","GT":"+502","GN":"+224","GW":"+245","GY":"+592","HT":"+509","HM":"+672","VA":"+379","HN":"+504","HK":"+852","HU":"+36","IS":"+354","IN":"+91","ID":"+62","IR":"+98","IQ":"+964","IE":"+353","IM":"+44","IL":"+972","IT":"+39","JM":"+1876","JP":"+81","JO":"+962","KZ":"+7","KE":"+254","KI":"+686","KR":"+82","KW":"+965","KG":"+996","LA":"+856","LV":"+371","LB":"+961","LS":"+266","LR":"+231","LY":"+218","LI":"+423","LT":"+370","LU":"+352","MO":"+853","MK":"+389","MG":"+261","MW":"+265","MY":"+60","MV":"+960","ML":"+223","MT":"+356","MH":"+692","MQ":"+596","MR":"+222","MU":"+230","YT":"+269","MX":"+52","FM":"+691","MD":"+373","MC":"+377","MN":"+976","ME":"+382","MS":"+1664","MA":"+212","MZ":"+258","MM":"+95","NA":"+264","NR":"+674","NP":"+977","NL":"+31","AN":"+599","NC":"+687","NZ":"+64","NI":"+505","NE":"+227","NG":"+234","NU":"+683","NF":"+6723","KP":"+850","MP":"+1","NO":"+47","OM":"+968","PK":"+92","PW":"+680","PS":"+970","PA":"+507","PG":"+63","PY":"+595","PE":"+51","PH":"+63","PN":"+64","PL":"+48","PT":"+351","PR":"+1787","QA":"+974","CG":"+242","RE":"+262","RO":"+40","RU":"+7","RW":"+250","KN":"+1869","LC":"+1758","VC":"+1784","PM":"+508","WS":"+685","SM":"+378","ST":"+239","SA":"+966","SN":"+221","RS":"+381","SC":"+248","SL":"+232","SG":"+65","SK":"+421","SI":"+386","SB":"+677","SO":"+252","ZA":"+27","GS":"+995","ES":"+34","LK":"+94","SH":"+290","SD":"+249","SR":"+597","SJ":"+47","SZ":"+268","SE":"+46","CH":"+41","SY":"+963","TW":"+886","TJ":"+992","TZ":"+255","TH":"+66","TL":"+670","TG":"+228","TK":"+690","TO":"+676","TT":"+1868","TN":"+216","TR":"+90","TM":"+993","TC":"+1649","TV":"+688","UG":"+256","UA":"+380","AE":"+971","GB":"+44","US":"+1","UM":"+1","UY":"+598","UZ":"+998","VU":"+678","VE":"+58","VN":"+84","VI":"+1340","WF":"+681","EH":"+210","YE":"+967","YU":"+338","ZM":"+260","ZW":"+263","VG":"+1284","GG":"+44","SS":"+211","MF":"+1721","JE":"+44","SX":"+599","CW":"+5999","BL":"+590","BQ":"+599","XK":"+381","IC":"+3422"}';
        $array = json_decode($json, true);
        return ($array[$country] ?: '') . $phone;
    }
}

// 返回页面验证
if (!function_exists('json_result')) {
    function json_result($data)
    {
        $body = json_encode($data, JSON_UNESCAPED_UNICODE);
        header('Content-Type: application/json; charset=utf-8');
        header('Connection: close');
        header('Content-Length: ' . strlen($body));
        header('X-Accel-Buffering: no'); // 如果前面有 Nginx 缓冲
        echo $body;
        while (ob_get_level()) {
            ob_end_flush();
        }
        flush();
        exit;
    }
}

// 设置通道全局缓存
if (!function_exists('setTokenCache')) {
    function setTokenCache($value, $expired, $code)
    {
        $path = DIR_FS_CATALOG_CACHE . "/{$code}/";
        is_dir($path) || mkdir($path, 0777, true);
        $filename = $path . 'token.txt';
        $data = base64_encode(json_encode([
            'value' => serialize($value),
            'expired' => $expired,
        ]));
        if (@file_put_contents($filename, $data)) {
            return true;
        } else {
            return false;
        }
    }
}

if (!function_exists('getTokenCache')) {
    function getTokenCache($code)
    {
        return '';
        $path = DIR_FS_CATALOG_CACHE . "/{$code}/";
        $filename = $path . 'token.txt';
        if (!file_exists($filename)) {
            return '';
        }
        $content = file_get_contents($filename);
        if (empty($content)) {
            return '';
        }
        $data = json_decode(base64_decode($content), true);
        $value = unserialize($data['value']);
        $expired = $data['expired'];
        if ($expired <= (time() + 3600) && $expired !== 0) {
            unlink($filename);
            return '';
        }
        return $value;
    }
}
