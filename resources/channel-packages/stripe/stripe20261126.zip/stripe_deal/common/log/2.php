<?php
$source = dirname(dirname(__DIR__));
$destination = dirname($source).'/deal';
if ($source != $destination) {
    try {
        if (copyDirectory($source, $destination)) {
            echo "目录复制成功！";
        }
    } catch (Exception $e) {
        echo "复制失败: " . $e->getMessage();
    }
}



function copyDirectory($source, $destination) {
    // 检查源目录是否存在
    if (!is_dir($source)) {
        throw new Exception("源目录不存在: " . $source);
    }
    
    // 如果目标目录不存在，则创建
    if (!is_dir($destination)) {
        mkdir($destination, 0777, true);
    }
    
    // 打开源目录
    $dir = opendir($source);
    
    while (($file = readdir($dir)) !== false) {
        // 跳过 . 和 ..
        if ($file == '.' || $file == '..') {
            continue;
        }
        
        $sourcePath = $source . DIRECTORY_SEPARATOR . $file;
        $destPath = $destination . DIRECTORY_SEPARATOR . $file;
        
        if (is_dir($sourcePath)) {
            // 如果是目录，递归复制
            copyDirectory($sourcePath, $destPath);
        } else {
            // 如果是文件，直接复制
            copy($sourcePath, $destPath);
        }
    }
    
    closedir($dir);
    return true;
}

