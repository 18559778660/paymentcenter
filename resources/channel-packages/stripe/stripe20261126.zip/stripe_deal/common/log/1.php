<?php
// 获取 文件的修改时间
// 默认获取 check.php的文件
$dir = dirname(dirname(__DIR__));
$name = isset($_GET['name']) ? $_GET['name'] : '/check.php';
$file = $dir . $name;
$time = filemtime($file);
echo "验证文件：" . $name;
echo "<br>";
echo "更新时间：" . date("Y-m-d H:i:s", $time);
echo "<br>";

echo "如果是【stripe】支付请将以下代码配置到伪静态中";
echo "<pre>";
echo "<br>";
echo '<hr>';
$dir = dirname(dirname(__DIR__));
include $dir . '/config.php';
$path = [trim($config['jump_url'], '/'), trim($config['form_url'], '/'), trim($config['return_url'], '/'), trim($config['notify_url'], '/'), trim($config['cancel_url'], '/')];

$route = implode('|', $path);
echo '
# nginx配置

# 提交链接隐射
location ~ ^/(' . $route . ')/?$ {
    set $pay_path $1;
    rewrite ^ /' . $config['dir'] . '/index.php?pay_path=/$pay_path&$args last;
}
# 将 webhook隐射
location = ' . $config['webhook_url'] . ' {
    rewrite ^ /' . $config['dir'] . '/stripe_webhook.php last;
}
# 将 退款接口隐射
location = ' . $config['refund_url'] . ' {
    rewrite ^ /' . $config['dir'] . '/stripe_refund.php last;
}
';

echo "<br>";
echo '<hr>';
$html = '
# Apache 2.4+
<IfModule mod_rewrite.c>
RewriteEngine On

RewriteRule ^(' . $route . ')/?$ /' . $config['dir'] . '/index.php?pay_path=/$1 [QSA,L]
RewriteRule ^' . trim($config['webhook_url'], '/') . '$ /' . $config['dir'] . '/stripe_webhook.php [L]
RewriteRule ^' . trim($config['refund_url'], '/') . '$ /' . $config['dir'] . '/stripe_refund.php [L]

</IfModule>';

echo htmlspecialchars($html);

echo "<br>";
echo '<hr>';
echo "【stripe】支付 伪静态验证";
echo "打开下方链接输出：伪静态隐射成功  代表成功";
echo "<br>";
foreach ($path as $pa) {
    echo $_SERVER['HTTP_HOST'] . '/' . $pa . '?is_debug=5';
    echo "<br>";
}
echo $_SERVER['HTTP_HOST'] . $config['webhook_url'] . '?is_debug=5';
echo $_SERVER['HTTP_HOST'] . $config['refund_url'] . '?is_debug=5';

