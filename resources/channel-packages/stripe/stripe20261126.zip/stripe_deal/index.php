<?php
ini_set('display_errors', '0');
error_reporting(E_ALL & ~E_STRICT);

if (!empty($_GET['is_debug']) && $_GET['is_debug'] == 5) {
    echo "伪静态隐射成功";die;
}
define('DIR_FS_CATALOG', str_replace('\\', '/', (dirname(dirname(__FILE__)))) . '/');
define('LOCATION_DIRS_FS', str_replace('\\', '/', (dirname(__FILE__))) . '/');
define('LOCATION_DIR_FS', basename(LOCATION_DIRS_FS));
require("./common/function.php");

if (empty($config['invoice']) || empty($_REQUEST[$config['invoice']])) {
    header("location: ./");
}

$invoice = $_REQUEST[$config['invoice']];
$xeppFileName = DIR_FS_CATALOG_CACHE . '/Invoice/' . $invoice . '.txt';

if (!is_file($xeppFileName)) {
    header("location: ./");
}

$page = !empty($_REQUEST['pay_path']) ? $_REQUEST['pay_path'] : '';
if (empty($page)) {
    $page = !empty($_REQUEST[$config['page']]) ? $_REQUEST[$config['page']] : '';
}
if (empty($page)) {
    header("location: ./");
}

$dataInfo = readOrderCache($xeppFileName);
$no_jump = '';
if (isset($_REQUEST['no_jump'])) {
    $dataInfo['no_jump'] = $_REQUEST['no_jump'];
    saveOrderCache($xeppFileName, $dataInfo);
}

foreach ($dataInfo as $key => $value) {
    $$key = $value;
}
if (isset($dataInfo[$page])){
    $filePath = $dataInfo[$page];
}else{
    $filePath = DIR_FS_CATALOG_PAYMENT . "{$payment_code}/{$page}.php";
}

if (!file_exists($filePath) || empty($payment_setting) || empty($order) || empty($order_goods) || empty($order_details)) {
    header("location: ./");
}

$currency_info = !empty($order_details['currency_info']) ? @json_decode($order_details['currency_info'], true) : [];
if (!isset($currency_info['code']) || !isset($currency_info['value'])) {
    header("location: ./");
}

$result_url = $order['result_url']; // A站返回页
$cancel_url = $order['cancel_url']; // A站取消页

$currency_ex = $currency_info['code'];
$amount_ex = $order['amount'];

$err_msg = 'Payment failed, please try again.';

if ($mode == 2) {
    if (!empty($dataInfo['pay_form_url'])) {
        $cancel_url = $dataInfo['pay_form_url'];
    }
}
$cancel_url = useGetParameters($cancel_url, 'payment_failed_msg=' . $err_msg);

$notify_data = [
    'no_jump' => $no_jump,
    'access_token' => $access_token,
    'notify_sys_url' => $notify_sys_url,
    'payment_code' => $payment_code,
    'sys_order_id' => $order_id,
    'order_number' => $order_number,
    'invoice_number' => $invoice,
    'pay_amount' => $amount_ex,
    'pay_currency' => $currency_ex,
    'show_amount' => isset($order['show_amount']) ? (string)$order['show_amount'] : 0,
    'show_usd_amount' => isset($order['show_usd_amount']) ? (string)$order['show_usd_amount'] : 0,
    'transaction_number' => '',
    'note' => '',
    'comment' => '',
    'channel_account_id' => $order['channel_account_id'],
    'channel_id' => $order['channel_id'],
    'b_domain_id' => $order['b_domain_id'],
];

require($filePath);
die;
