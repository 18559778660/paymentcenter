<?php
define('DIR_FS_CATALOG', str_replace('\\', '/', (dirname(dirname(__FILE__)))) . '/');
define('LOCATION_DIRS_FS', str_replace('\\', '/', (dirname(__FILE__))) . '/');
define('LOCATION_DIR_FS', basename(LOCATION_DIRS_FS));
require("./common/function.php");
$run_time['step_1'] = '文件入口: ' . date('Y-m-d H:i:s');
if (isset($_GET['debug'])) {
    if (isset($_GET['check_code'])) {
        if (!file_exists(DIR_FS_CATALOG_PAYMENT . $_GET['check_code'] . "/index.php")) {
            exit('error');
        }
    }
    exit('ok');
}

// 判断获取数据是否完整
$use_check = [
    'AccountInfo',
    'getInfoUrl',
    'InvoiceNumber',
    'OrderNumber',
    'Currency',
    'store_domain',
    'site_mode',
    'access_token'
];

foreach ($use_check as $check_item) {
    if (empty($_POST[$check_item])) {
        $error = [
            'code' => 1,
            'msg' => $check_item . ' cannot be empty!'
        ];
        exit(@json_encode($error, true));
    }
}


if (!isset($_POST['shipping_method_fee'])) {
    $error = [
        'code' => 1,
        'msg' => 'shipping_method_fee cannot be empty!'
    ];

    exit(@json_encode($error, true));
}


// 通过A站传递系统信息,向系统请求订单数据
$get_order_url = $_POST['getInfoUrl'];
$access_token = $_POST['access_token'];

$run_time['step_2'] = '参数判断完成: ' . date('Y-m-d H:i:s');

if (isset($_POST['get_order'])) {
    $orderInfo = json_decode(base64_decode($_POST['get_order']), true);
    unset($_POST['get_order']);
    // 检查订单信息是否获取成功
    if (empty($orderInfo)) {
        $error_data = [
            'code' => 1,
            'data' => $orderInfo,
            'msg' => '获取订单信息接收失败'
        ];
        exit(@json_encode($error_data, true));
    }
} else {
    // 通过A站传递系统信息,向系统请求订单数据
    $orderInfo_res = curl_pay($get_order_url, $access_token);
    $orderInfo = json_decode($orderInfo_res, true);

// 检查订单信息是否获取成功
    if (empty($orderInfo)) {
        $error_data = [
            'code' => 1,
            'data' => $orderInfo_res,
            'msg' => '获取订单信息查询失败' . $get_order_url
        ];
        exit(@json_encode($error_data, true));
    }
}

$run_time['step_3'] = '订单信息查询完成: ' . date('Y-m-d H:i:s');

if (!empty($orderInfo['error'])) {
    $err_msg = !empty($orderInfo['msg']) ? $orderInfo['msg'] : 'system error:1001!';
    $error_data = [
        'code' => 1,
        'msg' => $err_msg
    ];
    exit(@json_encode($error_data, true));
}

// 壳站存储订单信息
$invoiceNumber = $_POST['InvoiceNumber'];
$_POST['sys_order_all_info'] = $orderInfo;


// 判断该订单是否支付成功
$order_status = $orderInfo['order']['status'];

// 如果交易状态为0,则该订单支付成功无需再次支付
if ($order_status === 0 && !empty($orderInfo['order']['order_id'])) {
    $back_data = [
        'code' => 2,
        'pay_code' => 1, // pay_code为1,则为成功
        'pay_msg' => 'Pay Success!'
    ];
    exit(@json_encode($back_data, true));
}

// 根据账号信息引入支付
$account_info = $_POST['AccountInfo'];
if (!is_array($account_info)) {
    $account_info = json_decode($account_info, true);
}

$payment_setting = !empty($orderInfo['payment_setting']) ? json_decode($orderInfo['payment_setting'], true) : '';

if (empty($payment_setting)) {
    $error_data = [
        'code' => 1,
        'msg' => 'payment setting get fail!'
    ];
    exit(@json_encode($error_data, true));
}

if (empty($account_info["payment_type_info"]['payment_code'])) {
    $error_data = [
        'code' => 1,
        'msg' => 'account payment get fail!'
    ];
    exit(@json_encode($error_data, true));
}

$account_payment = $account_info["payment_type_info"]['payment_code'];

if (!file_exists(DIR_FS_CATALOG_PAYMENT . "{$account_payment}/index.php")) {
    $error_data = [
        'code' => 1,
        'msg' => "{$account_payment} payment interface does not exist in shell station!"
    ];
    exit(@json_encode($error_data, true));
}
$run_time['step_4'] = '支付信息配置完成: ' . date('Y-m-d H:i:s');
$invoiceNumber = $_POST['InvoiceNumber'];
$dataInfo = [
    'frame_id' => $account_info['frame_id'],
    'get_order_url' => $_POST['getInfoUrl'],
    'pay_checkout_url' => $_POST['sys_url'],
    'access_token' => $_POST['access_token'],
    'invoice_number' => $_POST['InvoiceNumber'],
    'order_number' => $orderInfo['order']['order_number'],
    'shipping_method_fee' => $_POST['shipping_method_fee'],
    'store_name' => $_POST['store_name'],
    'store_domain' => $_POST['store_domain'],
    'pay_process_url' => $_POST['pay_process_url'],
    'mode' => $_POST['site_mode'],
    'pay_form_url' => $orderInfo['order']['cancel_url'],
    'note_sys_url' => $_POST['sys_url'] . '/setDateTransacted',
    'notify_sys_url' => $_POST['sys_url'] . '/orderStatusUpdate',
    'check_sys_url' => $_POST['sys_url'] . '/checkOrderStatus',
    'payment_setting' => $payment_setting,
    'payment_code' => $account_info["payment_type_info"]['payment_code'],
    'is_return_check' => $account_info["is_return_check"],
    'goods_type' => $account_info["goods_type"],
    'order_no_type' => $account_info["order_no_type"],
    'ip_whitelist' => $account_info["ip_whitelist"],
//    'checkout_url' => HTTPS_SERVER . '/channel_xepp_url.php?InvoiceNumber=' . $invoiceNumber,
//    'checkout_html' => HTTPS_SERVER . '/channel_xepp_html.php?InvoiceNumber=' . $invoiceNumber,
//    'embedded_url' => HTTPS_SERVER . '/channel_xepp_embedded.php?InvoiceNumber=' . $invoiceNumber,

];

foreach ($payment_setting as $pay_set) {
    foreach ($pay_set as $key => $value) {
        $dataInfo[$key] = $value;
    }
}

$dataInfo['order'] = $orderInfo['order'];
$dataInfo['order_goods'] = $orderInfo['orderGoods'];
$dataInfo['order_details'] = $orderInfo['orderDetails'];
$dataInfo['order_id'] = $orderInfo['order']['id'];
$note_sys_data = [
    'invoiceNumber' => $invoiceNumber,
    'sys_order_id' => $dataInfo['order_id']
];
if (isset($config['type']) && $config['type'] == 1) {
    $invoiceNew = PHP56StringGenerator::generateOrderId($config['invoice_prefix'], $config['invoice_length'], $config['invoice_tag']);
    $invoiceInsinuate = DIR_FS_CATALOG_CACHE . '/invoice_insinuate/' . $invoiceNumber . '.txt';
    saveOrderCache($invoiceInsinuate, ['new_invoice' => $invoiceNew]);
} else {
    $invoiceNew = $invoiceNumber;
}

//$payment_file_url = HTTPS_SERVER . '/newpay/index.php?InvoiceNumber=' . $invoiceNumber;
$payment_file_url = HTTPS_SERVER . "/" . LOCATION_DIR_FS . "/?{$config['invoice']}=" . $invoiceNew;
foreach ($dataInfo as $key => $value) {
    $$key = $value;
}
$htmlFileName = DIR_FS_CATALOG_CACHE . '/Invoice/' . $invoiceNew . '.txt';
$dataInfo['invoiceNew'] = $invoiceNew;

$run_time['step_5'] = '新账单号设置完成: ' . date('Y-m-d H:i:s');
$dataInfo['run_time'] = $run_time;
require(DIR_FS_CATALOG_PAYMENT . "{$account_payment}/index.php");
die;
class PHP56StringGenerator
{
    /**
     * 生成订单ID（PHP 5.6版本）
     */
    public static function generateOrderId($prefix = 'ORD', $length = 24, $tag = 1)
    {
        $formats = [
            // 格式1: ORD-20160321-A1B2-1234
            function () use ($prefix) {
                $date = date('Ymd');
                $random = self::randomHex(4); // 4位十六进制
                $seq = str_pad(mt_rand(1, 9999), 4, '0', STR_PAD_LEFT);
                return "{$prefix}-{$date}-{$random}-{$seq}";
            },
            // 格式2: INV20160321A1B2C3
            function () use ($prefix) {
                $date = date('Ymd');
                $random = self::randomHex(6); // 6位十六进制
                return "{$prefix}{$date}{$random}";
            },
            // 格式3: TX-A1B2C3D4-20160321
            function () use ($prefix) {
                $random = self::randomHex(8); // 8位十六进制
                $date = date('Ymd');
                return "{$prefix}-{$random}-{$date}";
            },
            // 格式4: 混合字符
            function () use ($prefix, $length) {
                $chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
                $result = '';
                for ($i = 0; $i < $length; $i++) {
                    // 混合随机源
                    $seed = mt_rand() . microtime(true);
                    $index = hexdec(substr(md5($seed), 0, 8)) % strlen($chars);
                    $result .= $chars[$index];
                }
                return $prefix . '_' . $result;
            },
            // 格式5: SESS-XXXX-XXXX-XXXX
            function () use ($prefix, $length) {
                $m = ceil($length / 4);
                $parts = [];
                for ($i = 0; $i < $m; $i++) {
                    $parts[] = self::randomHex(4);
                }
                return $prefix . '-' . implode('-', $parts);
            },
        ];
        return $formats[$tag]();
    }


    /**
     * PHP 5.6兼容的十六进制生成
     */
    private static function randomHex($length)
    {
        $bytes_length = ceil($length / 2);
        $bytes = self::secure_random_bytes($bytes_length);

        // 确保有足够的字节
        if (strlen($bytes) < $bytes_length) {
            // 备用方案
            $hex = '';
            for ($i = 0; $i < $bytes_length; $i++) {
                $hex .= dechex(mt_rand(0, 255));
            }
            $bytes = pack('H*', $hex);
        }

        $hex = bin2hex($bytes);
        return substr($hex, 0, $length);
    }

    public static function secure_random_bytes($length)
    {
        $length = (int)$length;
        if ($length <= 0) {
            return '';
        }

        // 方法1: openssl扩展（最佳选择）
        if (function_exists('openssl_random_pseudo_bytes')) {
            $bytes = openssl_random_pseudo_bytes($length, $crypto_strong);
            if ($crypto_strong === true && strlen($bytes) >= $length) {
                return substr($bytes, 0, $length);
            }
        }

        // 方法2: /dev/urandom (Unix/Linux)
        static $urandom = true;
        if ($urandom && @is_readable('/dev/urandom')) {
            $fp = @fopen('/dev/urandom', 'rb');
            if ($fp !== false) {
                stream_set_read_buffer($fp, 0);
                $bytes = fread($fp, $length);
                fclose($fp);
                if ($bytes !== false && strlen($bytes) >= $length) {
                    return $bytes;
                }
            }
            $urandom = false; // 避免重复尝试失败
        }

        // 方法3: 混合随机源（备用方案）
        $bytes = '';
        $random_state = microtime() . print_r($_SERVER, true) . uniqid('', true);

        for ($i = 0; $i < $length; $i += 16) {
            $random_state = md5(microtime() . $random_state);
            $bytes .= pack('H*', md5($random_state));
        }

        return substr($bytes, 0, $length);
    }
}
