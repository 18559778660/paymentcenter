<?php
ini_set('display_errors', '0');
error_reporting(E_ALL & ~E_STRICT);

header("HTTP/1.1 200 OK");
header('Content-Type: application/json; charset=utf-8');
if ($_GET['is_debug']) {
    echo 'ok';
    die;
}
define('DIR_FS_CATALOG', str_replace('\\', '/', (dirname(dirname(__FILE__)))) . '/');
define('LOCATION_DIRS_FS', str_replace('\\', '/', (dirname(__FILE__))) . '/');
define('LOCATION_DIR_FS', basename(LOCATION_DIRS_FS));
require("./common/function.php");
define('PAYMENT_CODE', 'webhook');
$input = file_get_contents("php://input");
addChannelLog('stripe refund $input:' . $input, PAYMENT_CODE);
$param = json_decode($input, true);

$new_invoice = $param['invoice'];
$invoiceInsinuate = DIR_FS_CATALOG_CACHE . 'invoice_insinuate/' . $new_invoice . '.txt';
if (file_exists($invoiceInsinuate)) {
    $new = readOrderCache($invoiceInsinuate);
    if (empty($new['new_invoice'])) {
        $result = [
            'code' => 0, // 退款失败
            'data' => [],
            'msg' => '原订单数据查询失败,请到stripe后台退款'
        ];
        echo json_encode($result, JSON_UNESCAPED_UNICODE);
        return;
    } else {
        $new_invoice = $new['new_invoice'];
    }
}

$xeppFileName = DIR_FS_CATALOG_CACHE . 'Invoice/' . $new_invoice . '.txt';
if (!file_exists($xeppFileName)) {
    $result = [
        'code' => 0, // 退款失败
        'data' => [],
        'msg' => '之前的订单不支持代码退款,请到stripe后台退款'
    ];
    echo json_encode($result, JSON_UNESCAPED_UNICODE);
    return;
}

$xeppData = readOrderCache($xeppFileName);

$currency_info = !empty($xeppData['order_details']['currency_info']) ? @json_decode($xeppData['order_details']['currency_info'], true) : [];
if (!isset($currency_info['code']) || !isset($currency_info['value'])) {
    $result = [
        'code' => 0, // 退款失败
        'data' => [],
        'msg' => '原订单货币查询失败,请到stripe后台退款'
    ];
    echo json_encode($result, JSON_UNESCAPED_UNICODE);
    return;
}
$currency_ex = $currency_info['code'];
$amount_ex = $xeppData['order']['amount'];

require __DIR__ . '/stripe/vendor/autoload.php';
\Stripe\Stripe::setApiKey($xeppData['sk_secret']);

$param = [
    'payment_intent' => $param['transaction_number'],
    'metadata' => [
        $config['invoice'] => $new_invoice
    ]
];

if ($param['pay_amount'] < $amount_ex) {
    if (in_array($currency_ex, ["BIF", "CLP", "DJF", "GNF", "JPY", "KMF", "KRW", "MGA", "PYG", "RWF", "UGX", "VND", "VUV", "XAF", "XOF", "XPF"])) {
        $amount_final = intVal(ceil($amount_ex));
    } else {
        $amount_final = intVal(bcmul($amount_ex, 100));
    }
    //部分退款
    $param['amount'] = $amount_final;
}else{
    //全额退款
}

try {
    $refund = \Stripe\Refund::create($param);
    // 重点：StripeObject 使用 toArray() 导出数组
    addChannelLog('stripe refund $refund:' . json_encode($refund->toArray()), PAYMENT_CODE);

    if (in_array($refund->status, ['succeeded', 'pending'])) {
        $result = [
            'code' => 2, // 退款中
            'data' => $refund,
            'msg' => '退款中'
        ];
    } else {
        $result = [
            'code' => 0, // 退款失败
            'data' => $refund,
            'msg' => '退款失败'
        ];
    }
} catch (\Stripe\Exception\InvalidRequestException $e) {
    // 异常场景，也要写日志！！之前缺失这一段
    addChannelLog('stripe refund error: ' . $e->getMessage() . ' detail:' . json_encode($e->getError()), PAYMENT_CODE);
    $result = [
        'code' => 0,
        'data' => null,
        'msg' => $e->getMessage()
    ];
} catch (\Exception $e) {
    addChannelLog('stripe refund unknown error: ' . $e->getMessage(), PAYMENT_CODE);
    $result = [
        'code' => 0,
        'data' => null,
        'msg' => $e->getMessage()
    ];
}
echo json_encode($result, JSON_UNESCAPED_UNICODE);
return;
