<?php
addChannelLog($order_number . " return REQUEST:" . @json_encode($_REQUEST), $payment_code);
$redirect = $result_url;
// 返回页拦截判断
$is_return = pageVerification($dataInfo, $is_return_check);

require __DIR__ . '/vendor/autoload.php';
$stripe = new \Stripe\StripeClient($sk_secret);
$session_id = $dataInfo["session_id"];
$response = $stripe->checkout->sessions->retrieve($session_id, []);
addChannelLog($order_number . ' return $response: ' . @json_encode($response), $payment_code);
$id = "";
$payment_status = "";
if (isset($response->payment_intent)) {
    $id = $response->payment_intent;
}
if (isset($response->payment_status)) {
    $payment_status = $response->payment_status;
}

$notify_data["transaction_number"] = $id;
$commit = "return completed" . $payment_status;
if (in_array($payment_status, ["paid", "succeeded", "complete"])) {
    $notify_data["status"] = 1;
} else {
    $notify_data["status"] = 2;
}
// ------------ 代码 end --------------
$dataInfo["cache_order_status"] = $notify_data["status"];
$dataInfo["cache_order_clicks"] = 1;
saveOrderCache($xeppFileName, $dataInfo);

$notify_data["comment"] = $commit;
$re_arr = updateOrderStatus($notify_data, "return", !$is_return["status"]);
if (!empty($re_arr["redirect_next"])) {
    $redirect = $re_arr["redirect_next"];
}

// 检测IP
if ($is_return["status"]) {
    if ($is_return["status"] == 1){
        $error_sys_url = $pay_checkout_url . "errorOrderUpdate";
        $error_sys_data = [
            "sys_order_id" => $order_id,
            "ip" => $is_return["ip"],
            "order_ip" => $is_return["order_ip"],
            "browser" => $is_return["browser"],
            "note" => $is_return["note"],
            "payment_code" => $payment_code,
            "order_number" => $order_number
        ];
        curl_pay($error_sys_url, $dataInfo["access_token"], $error_sys_data);
    }

    redirect(HTTPS_SERVER);

}else{
    redirect($redirect);
}
die;
