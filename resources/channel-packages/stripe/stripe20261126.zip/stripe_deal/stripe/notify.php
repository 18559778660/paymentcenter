<?php
header("HTTP/1.1 200 OK");
addChannelLog($order_number . ' notify $_REQUEST:' . @json_encode($_REQUEST), $payment_code);

// ------------------ 处理程序 ---------------
$data = $_REQUEST;
if ($data['status'] == 1) {
    $status = 1;
    $notify_data['transaction_number'] = $data['resourcesSaleId'];
    $comment = 'notify:' . $data['msg'];
} else {
    $status = 2;
    $notify_data['transaction_number'] = $data['resourcesSaleId'];
    $comment = 'notify:' . $data['msg'];
}

// ------------------ 处理程序 END ---------------
$dataInfo['cache_order_status'] = $status;
saveOrderCache($xeppFileName, $dataInfo);

$notify_data['comment'] = $comment;
$notify_data['note'] = isset($data['note']) ? $data['note'] : '';
$notify_data['status'] = $status;
updateOrderStatus($notify_data, 'notify', false);

echo 'SUCCESS';
exit;
