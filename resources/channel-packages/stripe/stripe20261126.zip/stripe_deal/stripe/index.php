<?php
if (!isset($order['card_info'])) {
    $card_info = [];
} else {
    $card_info = array_filter(@json_decode($order['card_info'], true));
}


$meta_data = explode(',',$config['meta_data']);

$api_param = [
    $config['invoice'] => $invoiceNew
];
if (!empty($meta_data[0])) {
    $api_param[$meta_data[0]] = HTTPS_SERVER;
}
if (!empty($meta_data[1])) {
    $api_param[$meta_data[0]] = $order_id;
}
if (!empty($meta_data[2])) {
    $api_param[$meta_data[0]] = $order_number;
}

$dataInfo[$config['form_url']] = DIR_FS_CATALOG_PAYMENT . "{$payment_code}/form.php";
$dataInfo['form_url'] = HTTPS_SERVER . $config['form_url']. '?' . http_build_query($api_param);

$dataInfo[$config['jump_url']] = DIR_FS_CATALOG_PAYMENT . "{$payment_code}/jump.php";
$dataInfo['jump_url'] = HTTPS_SERVER . $config['jump_url']. '?' . http_build_query($api_param);

$dataInfo[$config['cancel_url']] = DIR_FS_CATALOG_PAYMENT . "{$payment_code}/cancel.php";
$dataInfo['cancel_url'] = HTTPS_SERVER . $config['cancel_url']. '?' . http_build_query($api_param);

$dataInfo[$config['notify_url']] = DIR_FS_CATALOG_PAYMENT . "{$payment_code}/notify.php";
$dataInfo['notify_url'] = HTTPS_SERVER . $config['notify_url']. '?' . http_build_query($api_param);

$dataInfo[$config['return_url']] = DIR_FS_CATALOG_PAYMENT . "{$payment_code}/return.php";
$dataInfo['return_url'] = HTTPS_SERVER . $config['return_url']. '?' . http_build_query($api_param);

$xepp_html_link = $dataInfo['form_url'];

$pay_code = 2;
$pay_html_type = 2;
if ($mode == 2 && !empty($card_info)) { // 内嵌模式
    $pay_html_type = 1;
} elseif ($mode == 4) { // 收银台模式
    $pay_code = 3;
}

$dataInfo['invoiceNew'] = $invoiceNew;
$dataInfo['approval_url'] = $xepp_html_link;
$dataInfo['approval_time'] = date('Y-m-d H:i:s');
//$note_sys_data['approval_url'] = base64_encode($xepp_html_link);
//$re_sys = curl_pay($note_sys_url, $access_token, $note_sys_data);

saveOrderCache($htmlFileName, $dataInfo);

$html_success_info = [
    'code' => 2, // code为2,有返回
    'pay_code' => $pay_code, // pay_code为2,支付中,自定义html内嵌
    'pay_skip_url' => $xepp_html_link,
    'pay_html_type' => $pay_html_type, // 1跳转，2显示表单
];

json_result($html_success_info);
