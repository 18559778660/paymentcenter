<?php

// 处理商品信息
if ($goods_type == 1 && $order['is_test'] < 2) {
    $file_mame_get_shell_goods = explode('_', $order_number)[0] . count($order_goods);
    $orderInfoGoods = getBDomainOrderGoods($file_mame_get_shell_goods, $amount_ex, $order_number);
} else {
    $orderInfoGoods = $order_goods;
}

$code = 1;
if (empty($dataInfo['session_id'])) {
    try {
        require __DIR__ . '/vendor/autoload.php';
        setWbSecret($pk_secret, $sk_secret, $wb_secret);
        $stripe = new \Stripe\StripeClient($sk_secret);
        $amount_final = $amount_ex;
        if (in_array($currency_ex, ["BIF", "CLP", "DJF", "GNF", "JPY", "KMF", "KRW", "MGA", "PYG", "RWF", "UGX", "VND", "VUV", "XAF", "XOF", "XPF"])) {
            $amount_final = intVal(ceil($amount_ex));
        } else {
            $amount_final = intVal(bcmul($amount_ex, 100));
        }
        $notify_data['pay_amount'] = $amount_ex;
        $notify_data['pay_currency'] = $currency_ex;
        $notify_data['status'] = 2;

        $customer_n = get_customer_n();

        if ($customer_n) {
            // 打乱 地址排序
            $bii_address = [
                'city' => toUTF_8($order_details['billing_city']),
                'country' => $order_details['billing_country'],
                'line1' => toUTF_8($order_details['billing_suburb'] . ' ' . $order_details['billing_street_address']),
                'line2' => toUTF_8($order_details['billing_suburb'] . ' ' . $order_details['billing_street_address']),
                'postal_code' => toUTF_8($order_details['billing_postcode']),
                'state' => getState($order_details['billing_region'], $order_details['billing_country']),
            ];
            $bii_address = random_pick_keys($bii_address, ['city', 'country', 'line1', 'line2', 'postal_code', 'state'], 'bii_address');

            $shop_address = [
                'city' => toUTF_8($order_details['shipping_city']),
                'country' => $order_details['shipping_country'],
                'line1' => toUTF_8($order_details['shipping_suburb'] . ' ' . $order_details['shipping_street_address']),
                'line2' => toUTF_8($order_details['shipping_suburb'] . ' ' . $order_details['shipping_street_address']),
                'postal_code' => toUTF_8($order_details['shipping_postcode']),
                'state' => getState($order_details['shipping_region'], $order_details['shipping_country']),
            ];
            $shop_address = random_pick_keys($shop_address, ['city', 'country', 'line1', 'line2', 'postal_code', 'state'], 'ship_address');

            // 打乱 用户字段
            $customer = [
                'email' => toUTF_8($order_details['billing_email']),
                'name' => trim(toUTF_8($order_details['billing_firstname']) . ' ' . toUTF_8($order_details['billing_lastname'])),
                'phone' => toUTF_8($order_details['billing_telephone']),
                'shipping' => [
                    'name' => trim(toUTF_8($order_details['billing_firstname']) . ' ' . toUTF_8($order_details['billing_lastname'])),
                    'phone' => toUTF_8($order_details['billing_telephone']),
                    'address' => $shop_address
                ],
                'address' => $bii_address
            ];
            $customer = random_pick_keys($customer, ['name', 'phone', 'shipping', 'address'], 'customer');
            $customer = $stripe->customers->create($customer);
        }

        // 打乱自定义字段
        $metadata = [
            $config['invoice'] => $invoiceNew,
            'source' => HTTPS_SERVER,
            'order_id' => $order_id,
            'order_no' => $order_number,
        ];
        $metadata = random_pick_keys($metadata, ['source', 'order_id', 'order_no'], 'metadata');

        // 价格生成方式
        $line_items = get_line_items($stripe, $amount_final, $currency_ex, $order_number, $orderInfoGoods[0]['name']);

        $body = [
            'mode' => 'payment',
            'cancel_url' => $dataInfo['cancel_url'] . "&session_id={CHECKOUT_SESSION_ID}",
            'success_url' => $dataInfo['return_url'] . "&session_id={CHECKOUT_SESSION_ID}",
            'client_reference_id' => $order_id,
            'line_items' => $line_items,
            'metadata' => $metadata,
        ];
        if ($customer_n) {
            $body['customer'] = $customer->id;
        } else {
            $body['customer_email'] = toUTF_8($order_details['billing_email']);
        }
        $body = random_pick_keys($body, ['client_reference_id'], 'body');

        addChannelLog($order_number . ' jump $body:' . @json_encode($body), $payment_code);
        $response = $stripe->checkout->sessions->create($body);
        $payment_method_types = implode(',', $response->payment_method_types);
        setCache($currency_ex, $payment_method_types);
        addChannelLog($order_number . ' jump $response:' . @json_encode($response), $payment_code);
        $session_id = $response->id;
        $redirect_url = $response->url;
    } catch (Exception $ex) {
        $comment = "error:" . $ex->getMessage();
    }
    if (!empty($comment)) {
        addChannelLog($order_number . ' jump error:' . $comment, $payment_code);
    } elseif (empty($session_id)) {
        $comment = "create session_id failed!";
    } else {
        $notify_data['status'] = 6;
        $dataInfo['session_id'] = $session_id;
        $dataInfo['stripe_redirect_url'] = $redirect_url;
        $dataInfo['cache_order_ip'] = get_client_ip();
        $dataInfo['cache_order_time'] = time();
        $dataInfo['cache_order_clicks'] = 0;
        $dataInfo['cache_order_user_agent'] = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
        $dataInfo['cache_order_status'] = $notify_data['status'];
        saveOrderCache($xeppFileName, $dataInfo);
        $comment = 'payment redirect!';
    }
} else {
    $notify_data['status'] = 6;
    $session_id = $dataInfo['session_id'];
    $redirect_url = $dataInfo['stripe_redirect_url'];
    $comment = 'payment redirect!';
}

$notify_data['comment'] = $comment;
updateOrderStatus($notify_data);

if ($notify_data['status'] != 6 && !empty($re_arr['redirect_next'])) {
    $redirect_url = $re_arr['redirect_next'];
}
if (isset($redirect_url)) {
    echo "<script> window.location.href = '{$redirect_url}' </script>";
} else {
    redirect($result_url);
}
die;

function get_customer_n()
{
    $path = DIR_FS_CATALOG_CACHE . '/st/';
    is_dir($path) || mkdir($path, 0777, true);
    $fileName = $path . "random_pick_keys_customer_n.txt";
    if (file_exists($fileName)) {
        $r = file_get_contents($fileName);
    }
    if (empty($r)) {
        $r = mt_rand(1000, 9999);
        @file_put_contents($fileName, $r);
    }
    if ($r < 7000) {
        return true;
    } else {
        return false;
    }
}

// $order_goods[0]['name']
function get_line_items($stripe, $amount_final, $currency_ex, $order_number, $goods_name)
{

    $path = DIR_FS_CATALOG_CACHE . '/st/';
    is_dir($path) || mkdir($path, 0777, true);
    $fileName = $path . "random_pick_keys_line_items_type.txt";
    if (file_exists($fileName)) {
        $r = file_get_contents($fileName);
    }
    if (empty($r)) {
        $r = mt_rand(1, 2);
        @file_put_contents($fileName, $r);
    }

    $product_name_arr = [
        '1' => 'Order No #' . $order_number,
        '2' => $order_number,
        '3' => !empty($goods_name) ? $goods_name : 'Special Offer ' . $order_number,
        '4' => 'All Products #' . $order_number
    ];

    // 商品的名称可以随机填充
    $productName = !empty($product_name_arr[$r]) ? $product_name_arr[$r] : $product_name_arr[0];

    if ($r == 1) {
        $product = $stripe->products->create(['name' => $productName]);
        $item = [
            'unit_amount' => $amount_final,
            'currency' => $currency_ex,
            'product' => $product->id,
        ];
        $item = random_pick_keys($item, [], 'product_item');
    } else {
        $item = [
            'unit_amount' => $amount_final,
            'currency' => $currency_ex,
            'product_data' => ['name' => $productName],
        ];
        $item = random_pick_keys($item, [], 'product_item');
    }
    return [
        [
            'price_data' => $item,
            'quantity' => 1,
        ]
    ];
}

/**
 * 随机打乱参数位置，同时随机保留 keys 的键值对
 * @param $data
 * @param $keys
 * @param $type
 * @return array
 */
function random_pick_keys($data, $keys, $type = 'address')
{
    $path = DIR_FS_CATALOG_CACHE . '/st/';
    if (!is_dir($path)) {
        mkdir($path, 0777, true);
    }

    $fileName = $path . "random_pick_keys_{$type}.txt";

    // 1) 如果有缓存：按缓存的 key 顺序拼回数组（只取 data 里存在的）
    if (is_file($fileName)) {
        $saved = json_decode((string)file_get_contents($fileName), true);
        if (is_array($saved)) {
            $out = [];
            foreach ($saved as $k) {
                if (array_key_exists($k, $data)) {
                    $out[$k] = $data[$k];
                }
            }
            return $out;
        }
        // 缓存坏了就继续重新生成
    }

    // 2) 只在 $keys 范围内随机保留 0~count(keys) 个
    $keys = array_values(array_unique($keys));
    $count = mt_rand(0, count($keys));
    $keepSet = array_flip(array_slice($keys, 0, $count)); // 用 set 判断更快更清晰

    // 3) 组装输出：保留 data 中不在 $keys 的字段；在 $keys 中的只保留被选中的
    $out = [];
    foreach ($data as $k => $v) {
        if (!in_array($k, $keys, true)) {
            $out[$k] = $v;                // 非目标字段：全保留
        } elseif (isset($keepSet[$k])) {
            $out[$k] = $v;                // 目标字段：只保留随机选中的
        }
    }

    $outKeys = array_keys($out);
    $shuffledOut = [];
    foreach ($outKeys as $k) {
        $shuffledOut[$k] = $out[$k];
    }

    // 5) 缓存“最终 key 顺序”
    @file_put_contents($fileName, json_encode($outKeys, JSON_UNESCAPED_UNICODE));
    return $shuffledOut;
}


function setCache($key, $val)
{
    $path = DIR_FS_CATALOG_CACHE . '/st/';
    is_dir($path) || mkdir($path, 0777, true);
    $filename = $path . "payment_method_types_{$key}.txt";
    if (@file_put_contents($filename, $val)) {
        return true;
    } else {
        return false;
    }
}

function setWbSecret($PublichKey, $SecretKey, $wb_secret)
{
    $path = DIR_FS_CATALOG_CACHE . '/st/';
    is_dir($path) || mkdir($path, 0777, true);
    $filename = $path . 'wb_secret.txt';
    $content = [
        'pk_secret' => $PublichKey,
        'sk_secret' => $SecretKey,
        'wb_secret' => $wb_secret,
    ];
    if (@file_put_contents($filename, json_encode($content))) {
        return true;
    } else {
        return false;
    }
}

?>
