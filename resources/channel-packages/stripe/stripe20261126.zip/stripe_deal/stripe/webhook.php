<?php
ini_set('display_errors', '0');
error_reporting(E_ALL & ~E_STRICT);

$input = @file_get_contents('php://input');
$data = json_decode($input, true);

// 通过接口 添加 webhook 事件订阅
require __DIR__ . '/vendor/autoload.php';
$sk_secret = $data['sk_secret'];
if (isset($data['is_fee'])) {
    \Stripe\Stripe::setApiKey($sk_secret);
    // 接收多个交易ID数组，前端传参 transaction_number[] = ["pi_xxx","pi_yyy"]
    $piIdList = $data['transaction_numbers'];

    $resultList = [];
    foreach ($piIdList as $piId) {
        $piId = trim($piId);
        if (empty($piId)) {
            $resultList[] = [
                'pi_id' => '',
                'status' => 'fail',
                'msg' => 'pi_id为空',
                'data' => null
            ];
            continue;
        }

        $item = [
            'pi_id' => $piId,
            'status' => '',
            'msg' => '',
            'data' => null
        ];

        try {
            $pi = \Stripe\PaymentIntent::retrieve($piId);
            $chargeId = $pi->latest_charge;

            if (empty($chargeId)) {
                $item['status'] = 'fail';
                $item['msg'] = "交易无charge记录";
                $resultList[] = $item;
                continue;
            }
            // 第二步：用chargeId单独拉Charge，expand balance_transaction！！这一步才是关键
            $charge = \Stripe\Charge::retrieve($chargeId, [
                'expand' => ['balance_transaction']
            ]);

            $txnId = $charge->balance_transaction;

            if (empty($txnId)) {
                // 还没生成余额交易，异步延迟，pending待重试
                $item['status'] = 'pending';
                $item['msg'] = "balance_transaction尚未生成，稍后重试";
                $resultList[] = $item;
                continue;
            }

            // =========关键：单独拉取balance_transaction对象=========
            $balanceTx = \Stripe\BalanceTransaction::retrieve($txnId);

            // ✅只要对象存在，不管status是 pending / available，手续费都是最终值，可以入库
            $fee = $balanceTx->fee;
            $net = $balanceTx->net;
            $feeDetailsArr = $balanceTx->fee_details;
            $feeCurrency = strtoupper($balanceTx->currency);
            $payCurrency = $pi->currency;
            $btStatus = $balanceTx->status; // pending / available
            $availableOn = $balanceTx->available_on;

            if (in_array($feeCurrency, ["BIF", "CLP", "DJF", "GNF", "JPY", "KMF", "KRW", "MGA", "PYG", "RWF", "UGX", "VND", "VUV", "XAF", "XOF", "XPF"])) {
                $fee = intVal($fee);
            } else {
                $fee = bcdiv($fee, 100, 2);
            }
            $item['status'] = 'success';
            $item['msg'] = '查询成功(资金待结算)';
            $item['data'] = [
                'pi_id' => $piId,
                'ch_id' => $charge->id,
                'txn_id' => $balanceTx->id,
                'fee' => $fee,
                'net' => $net,
                'fee_details' => json_encode($feeDetailsArr, JSON_UNESCAPED_UNICODE),
                'fee_currency' => $feeCurrency,
                'pay_currency' => $payCurrency,
                'bt_status' => $btStatus,
                'available_on' => $availableOn
            ];
            $resultList[] = $item;

            // 【可选】防止Stripe限流，每查一个停顿几十毫秒，批量量大开启
            // usleep(150000); // 0.15秒

        } catch (\Exception $e) {
            $item['status'] = 'error';
            $item['msg'] = "接口异常：" . $e->getMessage();
            $resultList[] = $item;
        }
    }

    // 返回全部批量结果
    exit(json_encode([
        'code' => 1,
        'msg' => '批量查询完成',
        'list' => $resultList
    ], JSON_UNESCAPED_UNICODE));
}

$stripe = new \Stripe\StripeClient($sk_secret);
// 列表（最多100条）
$list = $stripe->webhookEndpoints->all([
    'limit' => 100,
]);

$bool = false;
foreach ($list->data as $we) {
    if ($we->url == $data['callback_url']) {
        $bool = $we->id;
        break;
    }
}

if (!$bool) {
    try {
        $endpoint = $stripe->webhookEndpoints->create([
            'url' => $data['callback_url'],
            'enabled_events' => [
                'payment_intent.succeeded',
                'payment_intent.payment_failed',
                'checkout.session.completed',
                'charge.refunded'
            ],
            'api_version' => '2025-02-24.acacia', // 建议指定版本，保持事件数据稳定
        ]);
        echo json_encode(['code' => 1, 'data' => $endpoint->secret]);
    } catch (\Exception $e) {
        echo json_encode(['code' => 0, 'data' => "错误: " . $e->getMessage()]);
    }
} else {
    echo json_encode(['code' => 0, 'data' => '已经创建过回调，需要你去stripe后台手动查询']);
}
die;
