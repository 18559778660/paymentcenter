<?php
addChannelLog($order_number . ' cancel ', $payment_code);
// 返回页拦截判断
$is_return = pageVerification($dataInfo, $is_return_check);
$redirect = $result_url;
// ------------ 代码 start --------------
$notify_data['status'] = 3;
$notify_data['comment'] = 'cancel';

// ------------ 代码 end --------------
$dataInfo['cache_order_status'] = $notify_data['status'];
$dataInfo['cache_order_clicks'] = 1;
saveOrderCache($xeppFileName, $dataInfo);

$re_arr = updateOrderStatus($notify_data, 'cancel', !$is_return['status']);
if (!empty($re_arr['redirect_next'])) {
    $redirect = $re_arr['redirect_next'];
}

// 检测IP
if ($is_return['status']) {
    if ($is_return['status'] == 1){
        $error_sys_url = $pay_checkout_url . 'errorOrderUpdate';
        $error_sys_data = [
            'sys_order_id' => $order_id,
            'ip' => $is_return['ip'],
            'order_ip' => $is_return['order_ip'],
            'browser' => $is_return['browser'],
            'note' => $is_return['note'],
            'payment_code' => $payment_code,
            'order_number' => $order_number
        ];
        curl_pay($error_sys_url, $dataInfo['access_token'], $error_sys_data);
    }
    addChannelLog($order_number . ' cancel $error_data_json'. $error_data_json, $payment_code);
//    redirect(HTTPS_SERVER);
}else{
    redirect($redirect);
}
die;
