<?php
addChannelLog($order_number . ' form 1', $payment_code);
if (isset($_GET['debug']) && isset($dataInfo['cache_order_status'])){
    unset($dataInfo['cache_order_status']);
    saveOrderCache($xeppFileName, $dataInfo);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Transaction in Progress</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        html, body {
            margin: 0;
            padding: 0;
            background: #f2f8fc;
            font-family: Arial, sans-serif;
        }

        .container {
            max-width: 90%;
            width: 500px;
            margin: 10% auto;
            background: #fff;
            border-radius: 16px;
            padding: 40px 20px;
            text-align: center;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.05);
        }

        .loader-wrapper {
            position: relative;
            width: 140px;
            height: 140px;
            margin: 0 auto 60px;
        }

        .spinner-ring {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            border: 6px solid #b0d0f0;
            border-top: 6px solid #4aa4ff;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }

        .pulse-circle {
            position: absolute;
            top: 59%;
            left: 56%;
            width: 30px;
            height: 30px;
            border: 3px solid #4aa4ff;
            border-radius: 50%;
            background: transparent;
            transform: translate(-50%, -50%) scale(0.5);
            animation: pulse 2s ease-in-out infinite;
        }

        @keyframes spin {
            0%   { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        @keyframes pulse {
            0% {
                transform: translate(-50%, -50%) scale(0.5);
                opacity: 0.2;
            }
            50% {
                transform: translate(-50%, -50%) scale(1.2);
                opacity: 1;
            }
            100% {
                transform: translate(-50%, -50%) scale(0.5);
                opacity: 0.2;
            }
        }

        h2 {
            font-size: 18px;
            font-weight: bold;
            margin: 0;
            text-transform: uppercase;
        }

        p {
            color: #666;
            margin: 30px 0 50px;
            font-size: 14px;
        }

        .shield {
            width: 24px;
            height: 24px;
            margin: 0 auto;
        }

        @media (max-width: 480px) {
            .container {
                width: 80%;
                margin: 40% auto;
                padding: 30px 15px;
            }

            h2 {
                font-size: 16px;
            }

            p {
                font-size: 13px;
            }

            .loader-wrapper {
                width: 60px;
                height: 60px;
            }

            .pulse-circle {
                width: 24px;
                height: 24px;
                border-width: 2px;
            }

            .spinner-ring {
                border-width: 5px;
                border-top-width: 5px;
            }
        }
    </style>
</head>
<body>
<div class="container">
    <div class="loader-wrapper">
        <div class="spinner-ring"></div>
        <div class="pulse-circle"></div>
    </div>
    <h2>TRANSACTION IN PROGRESS<br>DO NOT CLOSE THIS PAGE</h2>
    <p>Order verification in progress...</p>
    <div class="shield">
        <svg viewBox="0 0 24 24" fill="#00d084" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 2L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-3zM11 17.93l-4.24-4.24 1.41-1.41L11 15.1l4.83-4.83 1.41 1.41L11 17.93z"/>
        </svg>
    </div>
</div>
<script>
    window.location.href = '<?php echo $jump_url;?>'
</script>
</body>
</html>

