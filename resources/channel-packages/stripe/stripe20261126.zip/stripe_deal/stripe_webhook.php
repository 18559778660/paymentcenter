<?php
ini_set('display_errors', '0');
error_reporting(E_ALL & ~E_STRICT);

if (!empty($_GET['is_debug']) && $_GET['is_debug'] == 5) {
    echo "伪静态隐射成功";
    die;
}
define('DIR_FS_CATALOG', str_replace('\\', '/', (dirname(dirname(__FILE__)))) . '/');
define('LOCATION_DIRS_FS', str_replace('\\', '/', (dirname(__FILE__))) . '/');
define('LOCATION_DIR_FS', basename(LOCATION_DIRS_FS));
require("./common/function.php");
$invoice_tag = $config['invoice'];
$dir = $config['dir'];

// 获取 Webhook 请求的内容
$payload = @file_get_contents('php://input');
$session_id = '';
define('PAYMENT_CODE', 'webhook');
$sig_header = $_SERVER['HTTP_STRIPE_SIGNATURE'];
require __DIR__ . '/stripe/vendor/autoload.php';

$secrets = getWbSecret();
$endpoint_secret = $secrets['wb_secret'];
$sk_secret = $secrets['sk_secret'];
$pk_secret = $secrets['pk_secret'];
$order_number = '';
try {
    // 验证 Webhook 签名并解析事件
    $event = \Stripe\Webhook::constructEvent($payload, $sig_header, $endpoint_secret);
    addChannelLog('new wb_callback' . ' event:' . json_encode($event));
    $code = 1;
    $comment = $event->type;
    if ($event->type == 'payment_intent.succeeded') {
        $code = 0;
        $paymentIntent = $event->data->object;
        $pay_type = implode(',', $paymentIntent->payment_method_types);
        if (isset($paymentIntent->metadata->$invoice_tag)) {
            $paymentIntentId = $paymentIntent->id;
            $invoiceNumber = $paymentIntent->metadata->$invoice_tag;
            $xeppFileName = DIR_FS_CATALOG_CACHE . '/Invoice/' . $invoiceNumber . '.txt';
            if (isset($paymentIntent->metadata->mode)){
                if ($paymentIntent->metadata->mode == 1){
                    // 自定义st
                    $xeppFileName = str_replace($dir, 'st_customize', $xeppFileName);
                }else{
                    // 游戏st
                    $xeppFileName = str_replace($dir, 'yxstripe', $xeppFileName);
                }
            }
            $xeppData = readOrderCache($xeppFileName);
            $order_number = $xeppData['order_number'];
            $url = $xeppData['notify_url'] . "&note={$pay_type}&status=1&resourcesSaleId={$paymentIntentId}&msg={$comment}";
            $response = @file_get_contents($url);
            if ($response == 'SUCCESS') {
                addChannelLog('new wb_callback' . $order_number . ' notify ' . $response);
            } else {
                addChannelLog('new wb_callback' . $order_number . ' notify_url ' . $url);
                addChannelLog('new wb_callback' . $order_number . ' notify ' . $response);
                addChannelLog('new wb_callback' . $order_number . ' notify failed');
            }
        }
    } elseif ($event->type == 'payment_intent.payment_failed') {
        $paymentIntent = $event->data->object;
        $pay_type = implode(',', $paymentIntent->payment_method_types);
        // 处理支付失败逻辑
        $comment = $paymentIntent->last_payment_error->message;
        $comment = urlencode($comment);
        if (isset($paymentIntent->metadata->$invoice_tag)) {
            $paymentIntentId = $paymentIntent->id;
            $invoiceNumber = $paymentIntent->metadata->$invoice_tag;
            $xeppFileName = DIR_FS_CATALOG_CACHE . '/Invoice/' . $invoiceNumber . '.txt';
            if (isset($paymentIntent->metadata->mode)){
                if ($paymentIntent->metadata->mode == 1){
                    // 自定义st
                    $xeppFileName = str_replace($dir, 'st_customize', $xeppFileName);
                }else{
                    // 游戏st
                    $xeppFileName = str_replace($dir, 'yxstripe', $xeppFileName);
                }
            }
            $xeppData = readOrderCache($xeppFileName);
            $order_number = $xeppData['order_number'];

            $url = $xeppData['notify_url'] . "&note={$pay_type}&status=0&resourcesSaleId={$paymentIntentId}&msg={$comment}";
            $response = @file_get_contents($url);
            if ($response == 'SUCCESS') {
                addChannelLog('new wb_callback' . $order_number . ' notify ' . $response);
            } else {
                addChannelLog('new wb_callback' . $order_number . ' notify_url ' . $url);
                addChannelLog('new wb_callback' . $order_number . ' notify ' . $response);
                addChannelLog('new wb_callback' . $order_number . ' notify failed');
            }
        }

    } elseif ('checkout.session.completed' == $event->type) {
        $sessionData = $event->data->object;
        if (isset($sessionData->metadata->$invoice_tag)) {
            $invoiceNumber = $sessionData->metadata->$invoice_tag;
            $xeppFileName = DIR_FS_CATALOG_CACHE . '/Invoice/' . $invoiceNumber . '.txt';
            if (isset($paymentIntent->metadata->mode)){
                if ($paymentIntent->metadata->mode == 1){
                    // 自定义st
                    $xeppFileName = str_replace($dir, 'st_customize', $xeppFileName);
                }else{
                    // 游戏st
                    $xeppFileName = str_replace($dir, 'yxstripe', $xeppFileName);
                }
            }
            $xeppData = readOrderCache($xeppFileName);
            $order_number = $xeppData['order_number'];
            $paymentIntentId = $sessionData->payment_intent;
            \Stripe\Stripe::setApiKey($sk_secret);
            $paymentIntent = \Stripe\PaymentIntent::retrieve($paymentIntentId);
            $pay_type = implode(',', $paymentIntent->payment_method_types);
            if ($paymentIntent->status == 'succeeded') {
                $url = $xeppData['notify_url'] . "&note={$pay_type}&status=1&resourcesSaleId={$paymentIntentId}&msg=succeeded";
            } else {
                if (isset($paymentIntent->last_payment_error->message)) {
                    $pay_msg = $paymentIntent->last_payment_error->message;
                } else {
                    $pay_msg = $paymentIntent->status;
                }
                $pay_msg = urlencode($pay_msg);
                $url = $xeppData['notify_url'] . "&note={$pay_type}&status=0&resourcesSaleId={$paymentIntentId}&msg={$pay_msg}";
            }
            $response = @file_get_contents($url);
            if ($response == 'SUCCESS') {
                addChannelLog('new wb_callback' . $order_number . ' notify ' . $response);
            } else {
                addChannelLog('new wb_callback' . $order_number . ' notify_url ' . $url);
                addChannelLog('new wb_callback' . $order_number . ' notify ' . $response);
                addChannelLog('new wb_callback' . $order_number . ' notify failed');
            }

        }
    } elseif (in_array($event->type, ['payment_method.updated', 'payment_method.detached', 'account.updated'])) {
        addChannelLog('new wb_callback' . ' 账号更新');
        addChannelLog('new wb_callback' . ' payload: ' . $payload);
    } elseif ($event->type == 'charge.refunded') {
        // 退款状态更新
        if (isset($paymentIntent->metadata->$invoice_tag)) {
            $paymentIntentId = $paymentIntent->id;
            $invoiceNumber = $paymentIntent->metadata->$invoice_tag;
            $xeppFileName = DIR_FS_CATALOG_CACHE . '/Invoice/' . $invoiceNumber . '.txt';
            if (isset($paymentIntent->metadata->mode)){
                if ($paymentIntent->metadata->mode == 1){
                    // 自定义st
                    $xeppFileName = str_replace($dir, 'st_customize', $xeppFileName);
                }else{
                    // 游戏st
                    $xeppFileName = str_replace($dir, 'yxstripe', $xeppFileName);
                }
            }
            $xeppData = readOrderCache($xeppFileName);
            $order_number = $xeppData['order_number'];
            $url = $xeppData['notify_url'] . "&status=4&resourcesSaleId={$paymentIntentId}&msg={$comment}";
            $response = @file_get_contents($url);
            if ($response == 'SUCCESS') {
                addChannelLog('new wb_callback' . $order_number . ' refund notify ' . $response);
            } else {
                addChannelLog('new wb_callback' . $order_number . ' refund notify_url ' . $url);
                addChannelLog('new wb_callback' . $order_number . ' refund notify ' . $response);
                addChannelLog('new wb_callback' . $order_number . ' refund notify failed');
            }
        }
    }
    // 返回 200 响应，表示成功接收并处理事件
    addChannelLog('new wb_callback' . $order_number . '  success');
    http_response_code(200);
} catch (\Stripe\Exception\SignatureVerificationException $e) {
    // 签名验证失败
    http_response_code(400);
    echo 'Webhook 验证失败';
    addChannelLog('new wb_callback' . $order_number . ' error 1');
    addChannelLog('new wb_callback' . $order_number . ' payload: ' . $payload);
} catch (Exception $e) {
    // 处理其他错误
    http_response_code(500);
    echo 'wb_callback 处理错误: ' . $e->getMessage();
    addChannelLog('new wb_callback' . $order_number . ' ' . $e->getMessage() . $e->getLine());
    addChannelLog('new wb_callback' . $order_number . ' ' . $payload);
}
die;
function getWbSecret()
{
    $path = DIR_FS_CATALOG_CACHE . '/st/';
    is_dir($path) || mkdir($path, 0777, true);
    $filename = $path . 'wb_secret.txt';
    $content = @file_get_contents($filename);
    if ($content) {
        return json_decode($content, true);
    } else {
        return [];
    }
}
