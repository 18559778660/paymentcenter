<?php
$config = [
    'dir' => 'stripe_deal',
    'invoice' => 'invoice', // 账单号
    'page' => 'page', // 页面路径
    'order_no' => 'order_no', // 页面路径
    'order_id' => 'order_id', // 页面路径
    'jump_url' => 'jump_page',
    'form_url' => 'form_page',
    'return_url' => 'return_page',
    'cancel_url' => 'cancel_page',
    'notify_url' => 'notify_page',
    'refund_url' => 'refund_page',
    'webhook_url' => 'webhook_page',
    'invoice_prefix' => 'ORD',
    'invoice_length' => '15',
    'invoice_tag' => 5,
    'type' => 0
];
