<?php
// === 配置 ===
$secret_token = 'abc123'; // 你设定的访问密钥
$output_file = __DIR__ . '/products_simple.xml'; // XML 输出路径

// === 验证 Token ===
if (!isset($_GET['token']) || $_GET['token'] !== $secret_token) {
    http_response_code(403);
    exit('无权限访问');
}

// === 加载 WordPress 环境（确保本文件位于根目录） ===
require_once __DIR__ . '/wp-load.php';

// === 查询 WooCommerce 商品 ===
$args = [
    'post_type' => 'product',
    'posts_per_page' => 50,
    'post_status' => 'publish'
];

$products = get_posts($args);

// === 构建 XML ===
$xml = new SimpleXMLElement('<Products/>');

foreach ($products as $product_post) {
    $product = wc_get_product($product_post->ID);
    if (!$product) continue;
    
    
    $url = base64_encode(get_permalink($product->get_id()));
    $name = base64_encode(htmlspecialchars($product->get_name()));
    $image = base64_encode(wp_get_attachment_url($product->get_image_id()));
    
// 可变商品处理
    if ($product->is_type('variable')) {
        $variations_data = [];

        foreach ($product->get_children() as $variation_id) {
            $variation = wc_get_product($variation_id);
            if (!$variation) continue;

            $attr_list = [];
            foreach ($variation->get_attributes() as $att_key => $att_val) {
                $clean_key = str_replace('attribute_', '', $att_key);
                $term = get_term_by('slug', $att_val, $clean_key);
                $attr_list[] = [
                    'option' => $clean_key,
                    'value'  => $term ? $term->name : $att_val
                ];
            }
            $sku = base64_encode($variation->get_sku());
            $attribute = base64_encode(json_encode($attr_list));
            $id = base64_encode($variation_id);
        
            $product1 = $xml->addChild('Product');
            $product1->addAttribute('id', $product->get_id());
            $product1->addChild('product_id', $id);
            $product1->addChild('name', $name);
            $product1->addChild('sku', $sku);
            $product1->addChild('attribute', $attribute);
            $product1->addChild('image', $image);
            $product1->addChild('url', $url);
        }

        $data['variations'] = $variations_data;
    }else{
        $sku = base64_encode($product->get_sku());
        $attribute = base64_encode(json_encode([]));
        $id = base64_encode($product->get_id());
    
        $product1 = $xml->addChild('Product');
        $product1->addAttribute('id', $product->get_id());
        $product1->addChild('product_id', $id);
        $product1->addChild('name', $name);
        $product1->addChild('sku', $sku);
        $product1->addChild('attribute', $attribute);
        $product1->addChild('image', $image);
        $product1->addChild('url', $url);
    }
    
}

// === 保存 XML 文件 ===
$filename = 'products_simple.xml';
$xml->asXML($filename);
echo "ok";
die;