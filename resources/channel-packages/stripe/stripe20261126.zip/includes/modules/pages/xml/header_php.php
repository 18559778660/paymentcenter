<?php

$sql = "SELECT `product_id`,`name`,`image`,`sku` FROM   " . TABLE_PRODUCT . " WHERE name IS NOT NULL AND `status` = 1 LIMIT 500;";
$product_name = [];
$result = $db->Execute($sql);
$count_use = 0;
// 创建根元素
$xml = new SimpleXMLElement('<Products/>');

if ($result->RecordCount() > 0) {
    while (!$result->EOF) {
        $op_sql = "SELECT pa.product_option_id, pa.product_option_value_id, po.name as op_name, pov.name as op_val_name FROM
	product_attribute AS pa
	JOIN product_option AS po ON pa.product_option_id = po.product_option_id
	JOIN product_option_value AS pov ON pa.product_option_value_id = pov.product_option_value_id 
WHERE pa.product_id = {$result->fields['product_id']}";
        $result_op = $db->Execute($op_sql);
        $attr_value = [];
        while (!$result_op->EOF) {
            $attr_value[$result_op->fields['op_name']][] = $result_op->fields['op_val_name'];
            $result_op->MoveNext();
        }

        $attribute = [];
        foreach ($attr_value as $att_key => $att) {
            $attribute[] = [
                'option' => $att_key,
                'value' => $att
            ];
        }
        $url = base64_encode("/index.php?main_page=product&pID=" . $result->fields['product_id']);
        $name = base64_encode($result->fields['name']);
        $sku = base64_encode($result->fields['sku']);
        $attribute = base64_encode(json_encode($attribute));
        $image = base64_encode('/' . get_image($result->fields['image'], ADDITIONAL_IMAGE_WIDTH, ADDITIONAL_IMAGE_HEIGHT));
        $id = base64_encode($result->fields['product_id']);

        $product1 = $xml->addChild('Product');
        $product1->addAttribute('id', $result->fields['product_id']);
        $product1->addChild('product_id', $id);
        $product1->addChild('name', $name);
        $product1->addChild('sku', $sku);
        $product1->addChild('attribute', $attribute);
        $product1->addChild('image', $image);
        $product1->addChild('url', $url);
        $result->MoveNext();
    }
}

// 保存为 XML 文件
$filename = 'products_simple.xml';
$xml->asXML($filename);

echo 'ok';
die;
?>
